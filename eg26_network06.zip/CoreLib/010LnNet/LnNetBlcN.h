// Interface for the CLnNetBlcN class.
// Network I/O Blocking
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetBlcN_H_
#define _LnNetBlcN_H_


class CLnNetBlcN : public CLnNetBase
{
protected:
	HANDLE			m_evSnd;		// Send�� Event
	CNwRingBuf		m_rbSnd;		// Send�� ������
	CNwRingBuf		m_rbRcv;		// Receive�� ������

protected:
	SOCKET			m_scCln;		// For Test
	SOCKADDR_IN		m_sdCln;		// For Test

public:
	CLnNetBlcN();
	virtual ~CLnNetBlcN();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Close();
	virtual INT		Listen();
	virtual INT		Connect(char* sIp=NULL, char* sPort=NULL);

	virtual INT		Send(char* sSrc, INT* iSnd);
	virtual INT		Recv(char* sDst, INT* iRcv);

	virtual DWORD	ProcRecv(void* pParam);
	virtual DWORD	ProcSend(void* pParam);
	virtual DWORD	ProcAccp(void* pParam);

protected:

};

#endif