// Implementation of the CLnNetSlctA class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"
#include "LnNetSlctA.h"



CLnNetSlctA::CLnNetSlctA()
{
}


CLnNetSlctA::~CLnNetSlctA()
{
}

INT CLnNetSlctA::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetSlctA Create\n");

	return 0;
}

void CLnNetSlctA::Destroy()
{
	printf("CLnNetSlctA Destroy\n");
}


INT CLnNetSlctA::Query(char* sCmd, void* pData)
{
	printf("CLnNetSlctA Query:%s\n", sCmd);

	if(0==_stricmp("Query", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}



