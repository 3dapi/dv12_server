// Interface for the CLnNetSlct class.
// Network I/O Select
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetSlct_H_
#define _LnNetSlct_H_


class CLnNetSlct : public CLnNetBase
{
protected:


public:
	CLnNetSlct();
	virtual ~CLnNetSlct();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		Query(char* sCmd, void* pData);

protected:

};

#endif
