// Server Application
//
////////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "Winmm.lib")

#include <vector>

#include <windows.h>
#include <Mmsystem.h>
#include <stdio.h>

#ifdef _DEBUG
	#pragma comment(lib, "../lib/LcNet_.lib")
#else
	#pragma comment(lib, "../lib/LcNet.lib")
#endif


#include "../include/LcNet/ILcNet.h"
#include "../include/LcNet/LcNetUtil.h"



ILcNet*		g_pNet=NULL;				// Network Instance


void main()
{
	printf("\n��Ʈ��ũ �غ�--------------------\n");

	// ������ �ʱ�ȭ
	if(FAILED(LcNet_WinSockCreate()))
		return;


	if(FAILED(LcNet_CreateTcpServer("IOCP", &g_pNet, NULL, "20000")))
		return;

	printf("\n\n��Ʈ��ũ ����--------------------\n");


	INT		hr	= -1;
	char	sBufSnd[1024]={0};
	char	sBufRcv[1024]={0};
	int		iLenSnd=0;
	int		iLenRcv=0;
	DWORD	dMsg= 0x0;

	while(1)
	{
//		Sleep(10);

		INT nCnt =0;

		if(SUCCEEDED(g_pNet->Query("Get Client Number", &nCnt)))
		{
			std::vector<SOCKET >	vSocket;
			g_pNet->Query("Get Socket List", &vSocket);

			int iSize = vSocket.size();


			for(int i=0; i<iSize; ++i)
			{
				SOCKET scH = vSocket[i];
		
				memset(sBufRcv, 0, sizeof sBufRcv);
				hr = g_pNet->Recv(sBufRcv, &iLenRcv, &dMsg, &scH);

				if(iLenRcv>0)
				{
					printf("Recv:%s\n", sBufRcv);
					sprintf(sBufSnd, "Echo:%s", sBufRcv);
					iLenSnd=strlen(sBufSnd);

					dMsg= 0xDeadBeaf;
					hr = g_pNet->Send(sBufSnd, iLenSnd, dMsg, scH);
				}
			}
		}

		if(FAILED(g_pNet->FrameMove()))
			break;
	}

	printf("\n��Ʈ��ũ ����--------------------\n\n");
	delete g_pNet;

	// ��������
	LcNet_WinsockDestroy();
}



