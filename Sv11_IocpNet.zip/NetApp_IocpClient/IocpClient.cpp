// Client Application
//
////////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "Winmm.lib")

#include <windows.h>
#include <Mmsystem.h>
#include <stdio.h>

#ifdef _DEBUG
	#pragma comment(lib, "../lib/LcNet_.lib")
#else
	#pragma comment(lib, "../lib/LcNet.lib")
#endif


#include "../include/LcNet/ILcNet.h"
#include "../include/LcNet/LcNetUtil.h"






ILcNet*		g_pNet=NULL;				// Network Instance


void main()
{
	printf("\n��Ʈ��ũ �غ�--------------------\n");

	// ������ �ʱ�ȭ
	if(FAILED(LcNet_WSAStartup()))
		return;

	
	if(FAILED(LcNet_CreateTcpClient("IOCP", &g_pNet, "127.0.0.1", "20000")))
		return;

	printf("\n\n��Ʈ��ũ ����--------------------\n");


	INT		hr	= -1;


	DWORD dBgn = timeGetTime();
	DWORD dEnd = dBgn;

	INT		iCnt=0;

	char	sBufSnd[1024]={0};
	char	sBufRcv[1024]={0};
	int		iLenSnd=0;
	int		iLenRcv=0;
	
	DWORD	dMsg= 0x0;

	while(1)
	{
		Sleep(10);

		memset(sBufRcv, 0, sizeof sBufRcv);

		

		hr = g_pNet->Recv(sBufRcv, &iLenRcv, &dMsg);

		if(iLenRcv>0)
		{
			printf("Recv:%s\n", sBufRcv);
		}


		dEnd = timeGetTime();
		
		if(dEnd>(dBgn+1000))
		{
			dBgn = dEnd;
			++iCnt;
			sprintf(sBufSnd, "Client Send %d", iCnt);
			iLenSnd=strlen(sBufSnd);

			dMsg= 0xDeadBeaf;
			hr = g_pNet->Send(sBufSnd, iLenSnd, dMsg);
		}

		if(FAILED(g_pNet->FrameMove()))
			break;
	}

	printf("\n��Ʈ��ũ ����--------------------\n\n");
	delete g_pNet;


	// ��������
	LcNet_WinsockDestroy();
}



