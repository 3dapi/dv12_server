// ILnDataBase.cpp: implementation of the ILnDataBase class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning(disable : 4786)

#include <vector>
#include <string>

using namespace std;


#import "C:\Program Files\Common Files\System\ADO\msado15.dll" \
no_namespace rename("EOF", "EndOfFile")


#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <stdio.h>

#include "ILnDataBase.h"
#include "LnDbBase.h"
#include "LnDbOdbc.h"
#include "LnDbOledb.h"


INT LnDB_Create(char* sCmd, ILnDataBase** pData)
{
	*pData = NULL;
	
	if(0==_stricmp("ODBC", sCmd))
	{
		CLnDbOdbc * pDB=NULL;

		pDB = new CLnDbOdbc;

		if(FAILED(pDB->Create()))
		{
			delete pDB;
			return -1;
		}

		*pData = pDB;
		return 1;
	}

	else if(0==_stricmp("OLDEDB", sCmd))
	{
		CLnDbOledb * pDB=NULL;

		pDB = new CLnDbOledb;

		if(FAILED(pDB->Create()))
		{
			delete pDB;
			return -1;
		}

		*pData = pDB;
		return 1;
	}

	return -1;
}


INT LnDB_CreateAndConnect(char* sCmd, ILnDataBase** pData, void* p1, void* p2, void* p3, void* p4, void* p5)
{
	*pData = NULL;
	
	if(0==_stricmp("ODBC", sCmd))
	{
		CLnDbOdbc * pDB=NULL;

		pDB = new CLnDbOdbc;

		if(FAILED(pDB->Create(p1, p2, p3, p4)))
		{
			pDB->Close();
			delete pDB;
			return -1;
		}

		*pData = pDB;
		return 1;
	}

	else if(0==_stricmp("OLEDB", sCmd))
	{
		CLnDbOledb * pDB=NULL;

		pDB = new CLnDbOledb;

		if(p5)
			pDB->Query("Set Host", p5);

		if(FAILED(pDB->Create(p1, p2, p3, p4)))
		{
			pDB->Close();
			delete pDB;
			return -1;
		}

		*pData = pDB;
		return 1;
	}

	return -1;
}
