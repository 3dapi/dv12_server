// Interface for the CLnNetBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetBase_H_
#define _LnNetBase_H_


class CLnNetBase : public ILnNet
{
public:
	enum ELnNetPrtcl
	{
		NETPRT_NONE	= 0,														// NONE
		NETPRT_TCP	= 1,														// TCP
		NETPRT_UDP	= 2,														// UDP
	};

	enum ELnNetHstType
	{
		NETHST_NONE		=0,														// NONE
		NETHST_CLIENT	=1,														// Client
		NETHST_SERVER	=2,														// Server
	};

	enum ELnNetEventType
	{
		NETEVT_NONE	=0,															// NONE
		NETEVT_SEND	=1,															// Send Event
		NETEVT_RECV =2,															// Receive
		NETEVT_ACCP =4,															// Accept
		NETEVT_CONN =8,															// Connect
		NETEVT_CLOSE=16,														// Close
	};

protected:
	SOCKET			m_scH;														// Host socket
	SOCKADDR_IN		m_sdH;														// Host Address
	char			m_sIp[32];													// IP
	char			m_sPt[16];													// Port

	INT				m_PtcType;													// Protocol type
	INT				m_HstType;													// Client or Server?

	HANDLE			m_hThRecv;													// Recv Thread Handle
	DWORD			m_dThRecv;													// Recv Thread Id
	INT				m_nThRecv;													// Recv Thread State

	HANDLE			m_hThSend;													// Send Thread Handle														// Thread Handle
	DWORD			m_dThSend;													// Send Thread Id
	INT				m_nThSend;													// Send Thread State

	HANDLE			m_hThAccp;													// Accept Thread Handle
	DWORD			m_dThAccp;													// Accept Thread Id
	INT				m_nThAccp;													// Accept Thread State

	INT				m_nThConn;													// Connection State

public:
	CLnNetBase();
	virtual ~CLnNetBase();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Close();
	virtual INT		Listen();
	virtual INT		Connect(char* sIp=NULL, char* sPort=NULL);

	virtual INT		Send(char* sSrc, INT* iSnd, SOCKET* scH=NULL);
	virtual INT		Recv(char* sDst, INT* iRcv, SOCKET* scH=NULL);

	virtual INT		IsConnect();

public:

	static DWORD WINAPI ThreadRecv(void* pParam);		// Receive�� ������
	static DWORD WINAPI ThreadSend(void* pParam);		// Send�� ������
	static DWORD WINAPI ThreadAccp(void* pParam);		// Accept�� ������

	virtual DWORD	ProcRecv(void* pParam);
	virtual DWORD	ProcSend(void* pParam);
	virtual DWORD	ProcAccp(void* pParam);
};

#endif
