// Implementation of the CLnDbOledb class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <stdio.h>

#include "ILnDataBase.h"
#include "LnDbBase.h"
#include "LnDbOledb.h"



CLnDbOledb::CLnDbOledb()
{
}


CLnDbOledb::~CLnDbOledb()
{

}


INT CLnDbOledb::Create(void* p1, void* p2, void* p3, void* p4)
{
	return -1;
}


void CLnDbOledb::Destroy()
{
}


INT CLnDbOledb::Query(char* sCmd, void* pData)
{
	return -1;
}



void CLnDbOledb::Close()
{
}



INT CLnDbOledb::Connect(void* pDataType, void* p1, void* p2, void* p3)
{
	return -1;
}


INT CLnDbOledb::SqlBind(char* sQuery, char*** sDataBufc,INT** nDataBufc, INT nBufSize)
{
	return -1;
}


INT CLnDbOledb::SqlExec()
{
	return -1;
}



INT CLnDbOledb::SqlClose()
{
	return -1;
}

