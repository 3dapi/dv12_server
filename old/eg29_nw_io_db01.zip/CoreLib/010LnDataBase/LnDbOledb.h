// Interface for the CLnDbOledb class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDbOledb_H_
#define _LnDbOledb_H_


class CLnDbOledb : public CLnDbBase
{
public:
	
protected:

public:	
	CLnDbOledb();
	virtual ~CLnDbOledb();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();
	virtual	INT		Query(char* sCmd, void* pData);

	
	virtual INT		Connect(void* pDataType, void* p1=0, void* p2=0, void* p3=0);
	virtual void	Close();

	virtual INT		SqlBind(char* sSQL, char*** sOutputBufc,INT** nDataBufc, INT nBufSize);
	virtual INT		SqlExec();
	virtual INT		SqlClose();
};


#endif


