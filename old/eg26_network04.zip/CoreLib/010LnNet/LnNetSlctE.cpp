// Implementation of the CLnNetSlctE class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"
#include "LnNetSlctE.h"



CLnNetSlctE::CLnNetSlctE()
{
}


CLnNetSlctE::~CLnNetSlctE()
{
}

INT CLnNetSlctE::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetSlctE Create\n");

	return 0;
}

void CLnNetSlctE::Destroy()
{
	printf("CLnNetSlctE Destroy\n");
}


INT CLnNetSlctE::Query(char* sCmd, void* pData)
{
	printf("CLnNetSlctE Query:%s\n", sCmd);

	if(0==_stricmp("Query", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}

