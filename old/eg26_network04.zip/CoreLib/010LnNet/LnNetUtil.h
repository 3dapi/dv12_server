// Interface for the LnNetUtil functions.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetUtil_H_
#define _LnNetUtil_H_


void	LnNet_FormatMessage(char* sMsg);		// Network Message Formating
void	LnNet_GetNetworkError(DWORD hr);		// Network Error Message Catching
INT		LnNet_WSAGetError();

INT		LnNet_WSAStartup();						// ���� ���̺귯�� �ʱ�ȭ
void	LnNet_WSACleanup();						// ���� ���̺귯�� ����


void	LnNet_SocketAddr(SOCKADDR_IN* pOut, char* sIp, char* sPort);			// Setting Socket Address

void	LnNet_SocketClose(SOCKET* scH);											// Socket Close

INT		LnNet_SocketTcpCreate(SOCKET* pScH, BOOL bOverLapped=FALSE);			// Create TCP Socket
INT		LnNet_SocketUdpCreate(SOCKET* pScH, BOOL bOverLapped=FALSE);			// Create UDP Socket

INT		LnNet_SocketConnect(SOCKET scH, SOCKADDR_IN* psdH);						// Connection

INT		LnNet_SocketBind(SOCKET scH, SOCKADDR_IN* pSdH);						// Socket Binding
INT		LnNet_SocketListen(SOCKET scH);											// Socket Listen
INT		LnNet_SocketAccept(SOCKET* pscOut			// Output Socket
							, SOCKADDR_IN* psdOut	// Output Socket Address
							, SOCKET scListen		// Listen socket
							);						// Accept





typedef unsigned (__stdcall* _PBEGIN_THREAD_EX)(void*);							// Thread�� �Լ�������
typedef _PBEGIN_THREAD_EX LPBEGIN_THREAD_EX;									//

HANDLE	LnNet_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,void* pParam, ULONG dFlag=0, DWORD* dId= NULL);	// Thread Create
void	LnNet_ThreadClose(HANDLE* hThread);																// Thread Close
DWORD	LnNet_ThreadResume(HANDLE* hThread);									// Thread resume
DWORD	LnNet_ThreadSuspend(HANDLE* hThread);									// Thread Suspend




// Interface for the CNwRingBuf functions.
//
////////////////////////////////////////////////////////////////////////////////

#define PCK_USE_BUF_POINTER	0
#define PCK_BUF_MAX_MSG		1024
#define PCK_BUF_MAX_QUEUE	4096
#define PCK_BUF_HEAD		2
#define PCK_BUF_TAIL		4


class CNwRingBuf
{
protected:
	INT		F;						// Header
	INT		L;						// Rear(Last)
	INT		W;						// Width
	INT		S;						// Stored

#if	PCK_USE_BUF_POINTER
	BYTE*	B;						// Buffer
#else
	BYTE	B[PCK_BUF_MAX_QUEUE];
#endif

public:
	CNwRingBuf();
	CNwRingBuf(INT iSize);
	virtual ~CNwRingBuf();

	void	SetSize(INT iSize);
	void	Clear()	;

	INT		End()	;
	INT		Front()	;
	INT		GetStore();

	INT		PushBack(BYTE* /* In*/pSrc, INT   iSize/*Length:  In*/);
	INT		PopFront(BYTE* /*Out*/pDst, WORD* iSize/*Length: Out*/);
};


#endif



