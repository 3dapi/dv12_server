// Implementation of the LnNetUtil functions.
//
////////////////////////////////////////////////////////////////////////////////

#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LnNetUtil.h"


void LnNet_FormatMessage(char* sMsg)
{
	LPVOID	pBuf;
	DWORD	hr= GetLastError();

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		hr,
		0,
		(LPTSTR) &pBuf,
		0,
		NULL 
	);

	sprintf(sMsg, "%s", (char*)pBuf);
	LocalFree( pBuf );
}



void LnNet_GetNetworkError(DWORD hr)
{
	char	sMsg[512];

	LnNet_FormatMessage(sMsg);

	printf("Error Line:%3d ", __LINE__);
	printf("%s	", __DATE__);
	printf("%s	", __TIME__);
	printf("%s	", __FILE__);

	printf("%s\n", sMsg);

	LocalFree( sMsg );
}



INT LnNet_WSAGetError()
{
	INT		hr = 0;
	char	sMsg[512];

	hr = WSAGetLastError();

	//������ �ƴ� ����.
	if(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr)
		return 0;

	LnNet_FormatMessage(sMsg);

	printf("Line:%d	", __LINE__);
	printf("%s	", __DATE__);
	printf("%s	", __TIME__);
	printf("%s	", __FILE__);

	printf("%s\n", sMsg);

	return -1;
}



INT LnNet_WSAStartup()
{
	INT		hr;
	WORD	wVersion;
	WSADATA wsaData;

	DWORD	iBuf =0;
	INT		nTCP[2] = {IPPROTO_TCP, IPPROTO_UDP};
 
	wVersion = MAKEWORD( 2, 2 );
 
	if ( 0 != WSAStartup( wVersion, &wsaData ))
		return -1;
 
	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 2 )
	{
		WSACleanup();
		return -1; 
	}

	// ������ ũ�⸸ ��ȯ�ϰ� ������ �߻��ؾ� �ȴ�.
	hr = WSAEnumProtocols(0, 0, &iBuf);

	if( (SOCKET_ERROR != hr) && (WSAENOBUFS != WSAGetLastError()) )
	{
		WSACleanup();
		return -1;
	}

	LPWSAPROTOCOL_INFO	pProtoInfo = (LPWSAPROTOCOL_INFO)malloc(iBuf);

	hr = WSAEnumProtocols(nTCP, pProtoInfo, &iBuf);
	free(pProtoInfo);

	if(SOCKET_ERROR ==hr)
	{
		WSACleanup();
		return -1; 
	}

	return 1;
}


void LnNet_WSACleanup()
{
	WSACleanup();
}


void LnNet_SocketAddr(SOCKADDR_IN* pOut, char* sIp, char* sPort)
{
	memset(pOut, 0, sizeof(SOCKADDR_IN));
	pOut->sin_family=AF_INET;

	pOut->sin_addr.s_addr = (sIp) ? inet_addr(sIp): htonl(INADDR_ANY);
	pOut->sin_port=htons(atoi(sPort));
}



void LnNet_SocketClose(SOCKET* scH)
{
	if(*scH<1)
		return;

	::shutdown(*scH, SD_BOTH);
	closesocket(*scH);
	*scH = 0;
}



INT LnNet_SocketTcpCreate(SOCKET* pScH, BOOL bOverLapped)
{
	if(bOverLapped)
		*pScH = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	else
		*pScH = socket(AF_INET, SOCK_STREAM, 0);

	
	if(INVALID_SOCKET == *pScH)
		return -1;

	return 1;
}



INT LnNet_SocketUdpCreate(SOCKET* pScH, BOOL bOverLapped)
{
	return -1;
}





INT LnNet_SocketConnect(SOCKET scH, SOCKADDR_IN* psdH)
{
	INT	hr=-1;

	hr = connect(scH, (SOCKADDR*)psdH, sizeof(SOCKADDR_IN));
	
	// ������ �񵿱��� ��� �̰��� �ݵ�� Ȯ��
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}
	}

	return 1;
}






INT LnNet_SocketBind(SOCKET scH, SOCKADDR_IN* pSdH)
{
	INT hr=-1;

	hr = bind(scH, (SOCKADDR*)pSdH, sizeof(SOCKADDR_IN));

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
		{
			return -1;
		}
	}

	return 1;
}


INT LnNet_SocketListen(SOCKET scH)
{
	INT hr=-1;

	hr = listen(scH, SOMAXCONN);

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
		{
			return -1;
		}
	}

	return 1;
}



INT LnNet_SocketAccept(SOCKET* pscOut, SOCKADDR_IN* psdOut, SOCKET scListen)
{
	INT		hr=-1;
	SOCKET	scCln;
	INT		iSizeAdd = sizeof(SOCKADDR_IN);

	scCln = accept(scListen, (SOCKADDR*)psdOut, &iSizeAdd);
//	scCln = WSAAccept(m_scH, (SOCKADDR*)&sdCln, &iSizeAdd, NULL, NULL);
	
	// ���������� �񵿱� �ϰ�� �̰��� �ݵ�� Ȯ��
	if(SOCKET_ERROR == scCln || INVALID_SOCKET ==scCln)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}

		// �񵿱���� ��� ���� �ִ�.
		*pscOut =0;
		return 0;
	}

	*pscOut = scCln;

	// ������ ����
	return 1;
}






HANDLE LnNet_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,PVOID pParam, ULONG dFlag, DWORD* dId)
{
	return (HANDLE)_beginthreadex(NULL, 0, (LPBEGIN_THREAD_EX)pFunc, pParam, dFlag, (unsigned*)dId);
}


void LnNet_ThreadClose(HANDLE* hThread)
{
	DWORD	dExit= 0;
	INT		hr	 = 0;
	
	if(0==hThread || 0 == *hThread)
		return;

	GetExitCodeThread(*hThread, &dExit);
	
	if(dExit)
	{
		SuspendThread(*hThread);

		if(0==TerminateThread(*hThread, dExit))
		{
			char	sMsg[512];
			LnNet_FormatMessage(sMsg);
			printf("%s\n", sMsg);
		}
	}

	//	WaitForSingleObject(m_hTh, INFINITE);
	CloseHandle(*hThread);
	*hThread = NULL;
}


DWORD LnNet_ThreadResume(HANDLE* hThread)
{
	if(0==hThread || 0 == *hThread)
		return 0;

	return ::ResumeThread(*hThread);
}


DWORD LnNet_ThreadSuspend(HANDLE* hThread)
{
	if(0==hThread || 0 == *hThread)
		return 0;

	return ::SuspendThread(*hThread);
}








// Implementation of the CNwRingBuf class.
//
////////////////////////////////////////////////////////////////////////////////	

CNwRingBuf::CNwRingBuf(): F(0), L(0), W(0), S(0)
{
#if	PCK_USE_BUF_POINTER
	B	= NULL;
	W	= 0;
#else
	W	= PCK_BUF_MAX_QUEUE;
	memset(B, 0, W);
#endif
}


CNwRingBuf::CNwRingBuf(INT iSize): F(0), L(0), W(iSize), S(0)
{
#if	PCK_USE_BUF_POINTER
	B	= new BYTE[W];
#endif
	memset(B, 0, W);
}


CNwRingBuf::~CNwRingBuf()
{
	W	= 0;
	F	= 0;
	L	= 0;

#if	PCK_USE_BUF_POINTER
	if(B)
	{
		delete [] B;
		B= NULL;
	}
#endif
}

void CNwRingBuf::SetSize(INT iSize)
{
	F	= 0;
	L	= 0;

#if	PCK_USE_BUF_POINTER
	W	= iSize;
	
	if(B)
	{
		delete [] B;
		B= NULL;
	}
	
	B	= new BYTE[W];
#else
	W	= PCK_BUF_MAX_QUEUE;
#endif
	
	memset(B, 0, W);
}



INT CNwRingBuf::End()		{	return L;	}
INT CNwRingBuf::Front()		{	return F;	}
INT CNwRingBuf::GetStore()	{	return S;	}

void CNwRingBuf::Clear()
{
	F	= 0;
	L	= 0;
	S	= 0;	
	memset(B, 0, W);
}

INT CNwRingBuf::PushBack(BYTE* /*In*/pSrc, INT iSize/*Length*/)
{
	// �� ������ ����...
	if( W<(iSize+S))
		return -1;

	INT	iLen = iSize;

	while(iLen--)
	{
		*(B+L) = *(pSrc++);
		++L;
		L %= W;
	}

	S +=iSize;

	return 1;
}


INT CNwRingBuf::PopFront(BYTE* /*Out*/pDst, WORD* iSize/*Length*/)
{
	BYTE	sSize[PCK_BUF_HEAD];
	INT		T= F;
	WORD	iLen=0;

	// ����Ʈ�� 2����Ʈ �̵����� ����.
	*(sSize+0) = *(B+T);
	++T;
	T%=W;

	*(sSize+1) = *(B+T);
	++T;
	T%=W;


	*iSize = 0;

	// �̵��ߴµ� L���� ũ�ų� ������ ���� �ϼ��� ��Ŷ�� ���ٴ� ��.
	if(T>=L)
		return -1;

	// ����Ǿ� �ִ� ��Ŷ�� ��
	iLen = *((WORD*)sSize);

	// ����� ����Ǿ� �ִ� �ͺ��� ũ�� ���� �ϼ��� ��Ŷ�� ����.
	if(iLen>S)
		return -1;

	//���� ���ۿ� ��Ŷ�� �����Ѵ�.
	WORD	iL= iLen;
	
	while (iLen--)
	{
		*(pDst++) = *(B + F);
		*(B + F) =0;

		++F;
		F %=W;
	}

	// ��ü �׿� �ִ� ��Ŷ�� ���� �����Ѵ�.
	S -= iL;
	*iSize = iL;

	return 1;
}