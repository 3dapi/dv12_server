// Implementation of the CLnNetIocp class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"
#include "LnNetIocp.h"



CLnNetIocp::CLnNetIocp()
{
}


CLnNetIocp::~CLnNetIocp()
{
}

INT CLnNetIocp::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetIocp Create\n");

	return 0;
}

void CLnNetIocp::Destroy()
{
	printf("CLnNetIocp Destroy\n");
}


INT CLnNetIocp::Query(char* sCmd, void* pData)
{
	printf("CLnNetIocp Query:%s\n", sCmd);

	if(0==_stricmp("Query", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}



