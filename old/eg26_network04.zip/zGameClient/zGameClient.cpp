// Client Application
//
////////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "Winmm.lib")

#include <windows.h>
#include <Mmsystem.h>
#include <stdio.h>


#include "../include/LnLib/ILnNet.h"


ILnNet*		g_pNet=NULL;				// Network Instance


void main()
{
	printf("\n��Ʈ��ũ �غ�--------------------\n");
	if(FAILED(LnNet_CreateTcpClient("Blocking", &g_pNet, "127.0.0.1", "20000")))
		return;

	printf("\n\n��Ʈ��ũ ����--------------------\n");


	
	DWORD dBgn = timeGetTime();
	DWORD dEnd = dBgn;

	INT		iCnt=0;

	char	sBufSnd[1024]={0};
	char	sBufRcv[1024]={0};
	int		iLenSnd=0;
	int		iLenRcv=0;

	while(1)
	{
		Sleep(10);

		memset(sBufRcv, 0, sizeof sBufRcv);
		g_pNet->Recv(sBufRcv, &iLenRcv);

		if(iLenRcv>0)
		{
			printf("Recv:%s\n", sBufRcv);
		}


		dEnd = timeGetTime();
		
		if(dEnd>(dBgn+1000))
		{
			dBgn = dEnd;
			++iCnt;
			sprintf(sBufSnd, "Client Send %d", iCnt);
			iLenSnd=strlen(sBufSnd);

			g_pNet->Send(sBufSnd, &iLenSnd);
		}
	}


	while(1)
	{
		char sMsg[128];
		fgets(sMsg, 128, stdin);
	}

	printf("\n��Ʈ��ũ ����--------------------\n\n");
	delete g_pNet;

	return;
}

