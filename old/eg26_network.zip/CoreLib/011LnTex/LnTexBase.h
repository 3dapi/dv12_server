// Interface for the CLnTex class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnTex_H_
#define _LnTex_H_


class CLnTex : public ILnTex
{
public:
	struct TLnTex
	{
		PDTX		m_pTx;					// D3DTexture Pointer
		DWORD		m_dC;					// Creation color Key
		DWORD		m_dF;					// Creation Filter

		DWORD		m_dP;					// Pool Types

		DIMG		m_Inf;
		char		m_sF[MAX_PATH];			// File Name

		TLnTex();
		void Release();
	};


protected:
	INT			m_nId;
	TLnTex		m_LnTx;

public:
	CLnTex();
	CLnTex(	INT _nId
			, PDTX _pTx
			, DWORD _dC
			, DWORD _dF
			, DWORD _dPool
			, const DIMG* _Inf
			, const char* _sFile);

	virtual ~CLnTex();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		Query(char* sCmd, void* pData);


	virtual DWORD	GetWidth();					// Get Width
	virtual DWORD	GetHeight();				// Get Height
	virtual DWORD	GetDepth();					// Get Depth
	virtual DWORD	GetMipLevel();				// Get Creation MipLevel
	virtual DWORD	GetFormat();				// Get enumeration from D3DFORMAT
	virtual DWORD	GetResourceType();			// Get enumeration from D3DRESOURCETYPE
	virtual DWORD	GetFileFormat();			// Get enumeration from D3DXIMAGE_FILEFORMAT
	virtual char*	GetSourceName();			// Get Source Name or File Name

	virtual void*	GetTex();					// Get D3DTexture Pointer
	virtual DWORD	GetColorKey();				// Get Creation color Key
	virtual DWORD	GetFilter();				// Get Creation Filter


	void	SetId(INT nId);
	void	SetTx(void* pTx);
	void	SetColorKey(DWORD dColorKey);
	void	SetFilter(DWORD dFilter);
	void	SetInfo(DIMG* pInf);
	void	SetFileName(char* sFile);
};


INT		LnD3D_TextureLoadFile(PDEV pDev,char* sFile
							, PDTX& pTexture
							, DWORD dColor=0x00FFFFFF
							, DIMG* pSrcInf=NULL
							, DWORD Filter		= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, DWORD MipFilter	= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, D3DFORMAT d3Fmt	= D3DFMT_UNKNOWN
							, DWORD Pool		= D3DPOOL_MANAGED);


INT		LnD3D_TextureLoadRscBmp(	//Resource�� ��Ʈ�ʸ� ����
							PDEV pDev, INT nResourceId
							, PDTX& pTexture
							, DWORD dColor=0x00FFFFFF
							, DIMG* pSrcInf=NULL
							, DWORD Filter		= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, DWORD MipFilter	= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, D3DFORMAT d3Fmt	= D3DFMT_UNKNOWN
							, DWORD Pool		= D3DPOOL_MANAGED);


INT		LnD3D_TextureLoadRscCustom(	// ��Ʈ�� �̿� PNG, JPG, TGA ���� ������ ����Ѵٸ� �� �Լ��� ����ؾ� �Ѵ�.
							PDEV pDev, INT nResourceId, const char* sType
							, PDTX& pTexture
							, DWORD dColor=0x00FFFFFF
							, DIMG* pSrcInf=NULL
							, DWORD Filter		= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, DWORD MipFilter	= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, D3DFORMAT d3Fmt	= D3DFMT_UNKNOWN
							, DWORD Pool		= D3DPOOL_MANAGED);



INT		LnD3D_TextureLoadMemory(PDEV pDev, void* pData, DWORD dSize
							, PDTX& pTexture
							, DWORD dColor=0x00FFFFFF
							, DIMG* pSrcInf=NULL
							, DWORD Filter		= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, DWORD MipFilter	= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
							, D3DFORMAT d3Fmt	= D3DFMT_UNKNOWN
							, DWORD Pool		= D3DPOOL_MANAGED);


INT		LnD3D_TextureFill(PDEV pDev, PDTX pTx, DWORD dColor= 0x0);


#endif
