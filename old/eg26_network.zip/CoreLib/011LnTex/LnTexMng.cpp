// Implementation of the CLnTexMng class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "../../include/LnLib/LnType.h"

#include "ILnTex.h"
#include "LnTexBase.h"
#include "LnTexMng.h"




CLnTexMng::CLnTexMng()
{
	m_nId	= -1;

	memset(m_sName, 0, sizeof m_sName);
}



CLnTexMng::~CLnTexMng()
{
	Destroy();
}


INT CLnTexMng::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;

	return 0;
}

void CLnTexMng::Destroy()
{
	if(!m_lsTex.empty())
	{
		for(itTLnTex	it= m_lsTex.begin(); it !=m_lsTex.end(); )
		{
			ILnTex* pLnTx = (*it).second;
			pLnTx->Destroy();
			delete pLnTx;
			++it;
		}

		m_lsTex.clear();
	}
}


INT CLnTexMng::Query(char* sCmd, void* pData)
{
	printf("CLnTexMng Query:%s\n", sCmd);
	return 0;
}


INT CLnTexMng::Find(char* sName, ILnTex** pData)
{
	char*		pstr = sName;
	itTLnTex	it;

	it = m_lsTex.find(pstr);

	if(it == m_lsTex.end())
	{
		*pData = NULL;
		return -1;
	}

	if(pData)
	{
		*pData = (*it).second;
	}
	
	return 1;
}

INT CLnTexMng::FindCreate(char* sCmd
						, ILnTex** pData
						, void* pVal1
						, void* pVal2
						, DWORD dColorKey
						, DWORD dFilter
						, DWORD Pool)
{
	INT hr=-1;
	char*	sName=(char*)pVal1;

	if(SUCCEEDED(Find(sName, pData)))
		return 1;

	// ������ ������ �����ϰ� ������ ������ ������
	

	hr = LnTex_CreateD3DTexture(sCmd
								, pData
								, m_pDev
								, pVal1
								, pVal2
								, dColorKey, dFilter, Pool);

	if(FAILED(hr))
		return -1;

	m_lsTex.insert(	mpTLnTex::value_type( sName, *pData));

	return 1;
}