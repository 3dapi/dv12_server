// Interface for the ILnTex class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnTex_H_
#define _ILnTex_H_

#ifndef interface
#define interface struct
#endif


#ifndef D3DX_FILTER_NONE
#define D3DX_FILTER_NONE	(1<<0)
#endif

interface ILnTex
{
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;
	virtual INT		Query(char* sCmd, void* pData)=0;

	virtual DWORD	GetWidth()=0;				// Get Width
	virtual DWORD	GetHeight()=0;				// Get Height
	virtual DWORD	GetDepth()=0;				// Get Depth
	virtual DWORD	GetMipLevel()=0;			// Get Creation MipLevel
	virtual DWORD	GetFormat()=0;				// Get enumeration from D3DFORMAT
	virtual DWORD	GetResourceType()=0;		// Get enumeration from D3DRESOURCETYPE
	virtual DWORD	GetFileFormat()=0;			// Get enumeration from D3DXIMAGE_FILEFORMAT
	virtual char*	GetSourceName()=0;			// Get Source Name or File Name

	virtual void*	GetTex()=0;					// Get D3DTexture Pointer
	virtual DWORD	GetColorKey()=0;			// Get Creation color Key
	virtual DWORD	GetFilter()=0;				// Get Creation Filter
};


typedef ILnTex*		PLNTEX;

// LnTex_CreateD3DTexture�Լ� ��� ����
// LnTex_CreateTexture("File"			, &pData, pd3dDevice, "Test.jpg");
// LnTex_CreateTexture("ResourceBmp"	, &pData, pd3dDevice, &ResourceId);
// LnTex_CreateTexture("ResourceCustom"	, &pData, pd3dDevice, &ResourceId, "UserCustomDefineType");
// LnTex_CreateTexture("ResourceCustom"	, &pData, pd3dDevice, &ResourceId, "PNG");
// LnTex_CreateTexture("Memory"			, &pData, pd3dDevice, pSrcData, &dSourceSize);


INT		LnTex_CreateD3DTexture(char* sCmd
							   , ILnTex** pData
							   , void* pD3Device
							   , void* pVal1
							   , void* pVal2 = NULL
							   , DWORD dColorKey=0x00FFFFFF
							   , DWORD dFilter= D3DX_FILTER_NONE
							   , DWORD Pool= D3DPOOL_MANAGED);




interface ILnTexMng
{
	// Basic Interface
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual INT		Query(char* sCmd, void* pData)=0;


	// Management Interface
	virtual INT		Find(char* sName, ILnTex** pData)=0;
	virtual INT		FindCreate(char* sCmd
								, ILnTex** pData
								, void* pVal1
								, void* pVal2 = NULL
								, DWORD dColorKey=0x00FFFFFF
								, DWORD dFilter= D3DX_FILTER_NONE
								, DWORD Pool= D3DPOOL_MANAGED)=0;
};


INT LnTex_CreateTexMng(char* sCmd, ILnTexMng** pData/*in-out value*/, void* pDev/*in value*/);




#ifdef _DEBUG
	#pragma comment(lib, "LnTex_.lib")
#else
	#pragma comment(lib, "LnTex.lib")
#endif


#endif

