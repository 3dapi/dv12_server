// Implementation of the CLnTex class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "../../include/LnLib/LnType.h"
#include "ILnTex.h"
#include "LnTexBase.h"


CLnTex::TLnTex::TLnTex()
{
	m_pTx	= 0;
	m_dC	= 0x00FFFFFF;
	m_dF	= D3DX_FILTER_NONE;
	m_dP	= D3DPOOL_MANAGED;

	memset(m_sF, 0, sizeof m_sF);
	memset(&m_Inf, 0, sizeof m_Inf);
}


void CLnTex::TLnTex::Release()
{
	if(m_pTx)
	{
		m_pTx->Release();
		m_pTx = NULL;
	}
}


CLnTex::CLnTex()
{
	m_nId	= -1;
}

CLnTex::CLnTex(INT _nId, PDTX _pTx, DWORD _dC, DWORD _dF, DWORD _dPool, const DIMG* _Inf,  const char* _sFile)
{
	m_nId		= _nId;
	m_LnTx.m_pTx= _pTx;
	m_LnTx.m_dC	= _dC;
	m_LnTx.m_dF	= _dF;
	m_LnTx.m_dP	= _dPool;

	memcpy(&m_LnTx.m_Inf, _Inf, sizeof m_LnTx.m_Inf);

	memset(m_LnTx.m_sF, 0, sizeof m_LnTx.m_sF);
	strcpy(m_LnTx.m_sF, _sFile);
}




CLnTex::~CLnTex()
{
	Destroy();
}


INT CLnTex::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnTex Create\n");
	return 0;
}

void CLnTex::Destroy()
{
	m_LnTx.Release();	
}

INT CLnTex::Query(char* sCmd, void* pData)
{
	printf("CLnTex Query:%s\n", sCmd);
	return 0;
}



DWORD	CLnTex::GetWidth()
{
	return m_LnTx.m_Inf.Width;
}

DWORD	CLnTex::GetHeight()
{
	return m_LnTx.m_Inf.Height;
}

DWORD	CLnTex::GetDepth()
{
	return m_LnTx.m_Inf.Depth;
}

DWORD	CLnTex::GetMipLevel()
{
	return m_LnTx.m_Inf.MipLevels;
}

DWORD	CLnTex::GetFormat()
{
	return m_LnTx.m_Inf.Format;
}

DWORD	CLnTex::GetResourceType()
{
	return m_LnTx.m_Inf.ResourceType;
}

DWORD	CLnTex::GetFileFormat()
{
	return m_LnTx.m_Inf.ImageFileFormat;
}

char*	CLnTex::GetSourceName()
{
	return m_LnTx.m_sF;
}

void*	CLnTex::GetTex()
{
	return m_LnTx.m_pTx;
}

DWORD	CLnTex::GetColorKey()
{
	return m_LnTx.m_dC;
}


DWORD	CLnTex::GetFilter()
{
	return m_LnTx.m_dF;
}


void CLnTex::SetId(INT nId)
{
	m_nId = nId;
}

void CLnTex::SetTx(void* pTx)
{
	m_LnTx.m_pTx = (PDTX)pTx;
}

void CLnTex::SetColorKey(DWORD dColorKey)
{
	m_LnTx.m_dC = dColorKey;
}

void CLnTex::SetFilter(DWORD dFilter)
{
	m_LnTx.m_dF = dFilter;
}

void CLnTex::SetInfo(DIMG* pInf)
{
	memcpy(&m_LnTx.m_Inf, pInf, sizeof( m_LnTx.m_Inf));
}

void CLnTex::SetFileName(char* sFile)
{
	if(sFile)
	{
		strcpy(m_LnTx.m_sF, sFile);
	}
}



INT LnTex_CreateD3DTexture(char* sCmd, ILnTex** pData, void* pD3Device, void* pVal1, void* pVal2, DWORD dColorKey, DWORD dFilter, DWORD Pool)
{
	(*pData) = NULL;

	CLnTex* pObj = NULL;

	PDEV	pDev = (PDEV)pD3Device;
	char*	sFile=(char*)pVal1;
	PDTX	pTexture;
	DWORD	dColor = dColorKey;
	DWORD	Filter=dFilter;
	DWORD	MipFilter= dFilter;
	DIMG	pSrcInf;
	

//	INT		LnTex_CreateTexture("File", "Test.jpg", NULL, ILnTex** pData);
//	INT		LnTex_CreateTexture("ResourceBmp", &ResourceId, NULL, ILnTex** pData);
//	INT		LnTex_CreateTexture("ResourceCustom", &ResourceId, "UserCustomDefineType", ILnTex** pData);
//	INT		LnTex_CreateTexture("ResourceCustom", &ResourceId, "PNG", ILnTex** pData);
//	INT		LnTex_CreateTexture("Memory", pSrcData, &dSourceSize, ILnTex** pData);

	if(0==_stricmp("File", sCmd))
	{
		if(FAILED(LnD3D_TextureLoadFile(pDev, sFile,pTexture, dColor, &pSrcInf, Filter, MipFilter)))
			return -1;
	}

	pObj = new CLnTex(-1, pTexture, dColor,  Filter, Pool, &pSrcInf, sFile);

	(*pData) = pObj;

	return 0;
}




// Texture Load
INT LnD3D_TextureLoadFile(PDEV pDev,char* sFile
						, PDTX& pTexture
						, DWORD dColor
						, DIMG* pSrcInf
						, DWORD Filter
						, DWORD MipFilter
						, D3DFORMAT d3Fmt
						, DWORD Pool)
{
	HRESULT hr;

	UINT uMip = D3DX_DEFAULT;

	if(D3DX_FILTER_NONE == Filter || D3DX_FILTER_NONE == MipFilter)
		uMip = 1;

	hr=D3DXCreateTextureFromFileEx(pDev
			, sFile
			, D3DX_DEFAULT, D3DX_DEFAULT
			, uMip
			, 0
			, d3Fmt
			, (D3DPOOL)Pool
			, Filter, MipFilter
			, dColor, pSrcInf
			, NULL
			, &pTexture		);

	if(FAILED(hr))
	{
		pTexture = 0;
		return hr;
	}

	return 1;
}


INT LnD3D_TextureLoadRscBmp(PDEV pDev, INT nResourceId
							, PDTX& pTexture
							, DWORD dColor
							, DIMG* pSrcInf
							, DWORD Filter
							, DWORD MipFilter
							, D3DFORMAT d3Fmt
							, DWORD Pool)
{
	HRESULT		hr;
	HINSTANCE	hInst = NULL;

	UINT uMip = D3DX_DEFAULT;

	if(D3DX_FILTER_NONE == Filter || D3DX_FILTER_NONE == MipFilter)
		uMip = 1;

	hInst = GetModuleHandle(NULL);

	// DirectX Help���� �̷��� ���� �ִ�.
	// The resource being loaded must be of type RT_BITMAP or RT_RCDATA.
	// Resource type RT_RCDATA is used to load formats other than bitmaps (such as .tga, .jpg, and .dds).
	// ������ LnD3D_TextureLoadRscCustomó�� �ϴ� ���� �� ����.
	// �ֳ� �ϸ� D3DXCreateTextureFromResourceEx�Լ��� ���ҽ� Ÿ���� ������ �ƹ��� ���ڰ� ����.
	// �� �Լ��� ��Ʈ�ʸ� ����� �� �ִ�.

	hr=D3DXCreateTextureFromResourceEx(pDev, hInst
			, MAKEINTRESOURCE(nResourceId)
			, D3DX_DEFAULT
			, D3DX_DEFAULT
			, uMip
			, 0
			, d3Fmt
			, (D3DPOOL)Pool
			, Filter, MipFilter
			, dColor, pSrcInf
			, NULL
			, &pTexture		);

	if(FAILED(hr))
	{
		pTexture = 0;
		return hr;
	}

	return 1;
}



INT LnD3D_TextureLoadRscCustom(PDEV pDev, INT nResourceId, const char* sType
								, PDTX& pTexture
								, DWORD dColor
								, DIMG* pSrcInf
								, DWORD Filter
								, DWORD MipFilter
								, D3DFORMAT d3Fmt
								, DWORD Pool)
{
	HINSTANCE	hInst	= NULL;
	HRSRC		hRsc	= NULL;
	DWORD		dwSize	= 0;
	HGLOBAL		hMem	= NULL;
	LPVOID		pMem	= NULL;

	HRESULT hr;

	UINT uMip = D3DX_DEFAULT;

	if(D3DX_FILTER_NONE == Filter || D3DX_FILTER_NONE == MipFilter)
		uMip = 1;


	hInst = GetModuleHandle(NULL);
	hRsc = FindResource( hInst, MAKEINTRESOURCE(nResourceId), sType);

	if(NULL == hRsc)
		return -1;

	dwSize = SizeofResource(hInst,hRsc);

	if(0==dwSize)
		return -1;

	hMem = LoadResource(hInst, hRsc);

	if(NULL == hMem)
		return -1;

	pMem = LockResource(hMem);

	// �̰��� �ȵȴ�...
	//	HRESULT hr = D3DXCreateTextureFromResourceEx(
	//		pDev
	//		, NULL
	//		, MAKEINTRESOURCE(IDR_PNG1)
	//		, D3DX_DEFAULT
	//		, D3DX_DEFAULT
	//		, uMip
	//		, 0
	//		, d3Fmt
	//		, Pool
	//		, Filter, MipFilter
	//		, dColor, pSrcInf
	//		, NULL
	//		, &pTexture);



	// �̰����� �ؾ� �Ѵ�.

	hr = D3DXCreateTextureFromFileInMemoryEx(
		pDev
		, pMem
		, dwSize
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, uMip
		, 0
		, d3Fmt
		, (D3DPOOL)Pool
		, Filter, MipFilter
		, dColor, pSrcInf
		, NULL
		, &pTexture);

	UnlockResource(hMem);
	FreeResource(hMem);

	if(FAILED(hr))
		return -1;

	return 1;
}


INT LnD3D_TextureLoadMemory(PDEV pDev, void* pData
							, UINT dSize
							, PDTX& pTexture
							, DWORD dColor
							, DIMG* pSrcInf
							, DWORD Filter
							, DWORD MipFilter
							, D3DFORMAT d3Fmt
							, DWORD Pool)
{
	HRESULT hr;

	UINT uMip = D3DX_DEFAULT;

	if(D3DX_FILTER_NONE == Filter || D3DX_FILTER_NONE == MipFilter)
		uMip = 1;

	hr=D3DXCreateTextureFromFileInMemoryEx(pDev
			, pData
			, dSize
			, D3DX_DEFAULT
			, D3DX_DEFAULT
			, uMip
			, 0
			, d3Fmt
			, (D3DPOOL)Pool
			, Filter, MipFilter
			, dColor, pSrcInf
			, NULL
			, &pTexture		);

	if(FAILED(hr))
	{
		pTexture = 0;
		return hr;
	}

	return 1;
}





INT LnD3D_TextureFill(PDEV pDev, PDTX pTx, DWORD dColor)
{
	INT hr = -1;
	PDSF pSurface = NULL;
	
	hr = pTx->GetSurfaceLevel( 0, &pSurface );

	if( SUCCEEDED(hr) )
		pDev->ColorFill( pSurface, NULL, 0x0);
	
	pSurface->Release();

	return hr;
}