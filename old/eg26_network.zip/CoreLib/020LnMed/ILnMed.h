// Interface for the ILnMed class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnMed_H_
#define _ILnMed_H_

#ifndef interface
#define interface struct
#endif




interface ILnMed
{
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;
	virtual void	Render()=0;


	virtual INT		Query(char* sCmd, void* pData)=0;
};


INT LnInst_CreateMed(char* sCmd, ILnMed** pData);


#ifdef _DEBUG
	#pragma comment(lib, "LnMed_.lib")
#else
	#pragma comment(lib, "LnMed.lib")
#endif


#endif

