// Interface for the CLnFont class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnFont_H_
#define _LnFont_H_


class CLnFont : public ILnFont
{
protected:
	INT		nId;

public:
	CLnFont();
	virtual ~CLnFont();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
