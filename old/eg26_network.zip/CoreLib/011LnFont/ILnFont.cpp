// Implementation of the ILnFont class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "ILnFont.h"
#include "LnFontBase.h"


INT LnObj_CreateFont(char* sCmd, ILnFont** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Font", sCmd))
	{
		CLnFont* pObj = NULL;

		pObj = new CLnFont;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	return -1;
}
