// Application class for the Direct3D samples framework library.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>

#include <D3D9.h>
#include <D3DX9.h>

#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"


// Message handling function.
LRESULT CD3DApplication::MsgProc(HWND hWnd,UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM wLo = LOWORD(wParam);

	switch( uMsg )
	{
	case WM_PAINT:
		// Handle paint messages when the app is paused
		if( m_pd3dDevice && !m_bActive && m_bWindowed &&
			m_bDeviceObjectsInited && m_bDeviceObjectsRestored )
		{
			Render();
			m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
		}
		break;
		
	case WM_GETMINMAXINFO:
		((MINMAXINFO*)lParam)->ptMinTrackSize.x = 100;
		((MINMAXINFO*)lParam)->ptMinTrackSize.y = 100;
		break;
		
	case WM_ENTERSIZEMOVE:
		// Halt frame movement while the app is sizing or moving
		Pause( TRUE );
		break;
		
	case WM_SIZE:
		// Pick up possible changes to window style due to maximize, etc.
		if( m_bWindowed && m_hWnd != NULL )
			m_dwWindowStyle = GetWindowLong( m_hWnd, GWL_STYLE );
		
		if( SIZE_MINIMIZED == wParam )
		{
			if( m_bClipCursorWhenFullscreen && !m_bWindowed )
				ClipCursor( NULL );
			Pause( TRUE ); // Pause while we're minimized
			m_bMinimized = TRUE;
			m_bMaximized = FALSE;
		}
		else if( SIZE_MAXIMIZED == wParam )
		{
			if( m_bMinimized )
				Pause( FALSE ); // Unpause since we're no longer minimized
			m_bMinimized = FALSE;
			m_bMaximized = TRUE;
			HandlePossibleSizeChange();
		}
		else if( SIZE_RESTORED == wParam )
		{
			if( m_bMaximized )
			{
				m_bMaximized = FALSE;
				HandlePossibleSizeChange();
			}
			else if( m_bMinimized)
			{
				Pause( FALSE ); // Unpause since we're no longer minimized
				m_bMinimized = FALSE;
				HandlePossibleSizeChange();
			}
			else
			{
				// If we're neither maximized nor minimized, the window size 
				// is changing by the user dragging the window edges.  In this 
				// case, we don't reset the device yet -- we wait until the 
				// user stops dragging, and a WM_EXITSIZEMOVE message comes.
			}
		}
		break;
		
	case WM_EXITSIZEMOVE:
		Pause( FALSE );
		HandlePossibleSizeChange();
		break;
		
	case WM_SETCURSOR:
		// Turn off Windows cursor in fullscreen mode
		if( m_bActive && !m_bWindowed )
		{
			SetCursor( NULL );
			if( m_bShowCursorWhenFullscreen )
				m_pd3dDevice->ShowCursor( TRUE );
			return TRUE; // prevent Windows from setting cursor to window class cursor
		}
		break;
		
	case WM_MOUSEMOVE:
		if( m_bActive && m_pd3dDevice != NULL )
		{
			POINT ptCursor;
			GetCursorPos( &ptCursor );
			
			if( !m_bWindowed )
				ScreenToClient( m_hWnd, &ptCursor );

			m_pd3dDevice->SetCursorPosition( ptCursor.x, ptCursor.y, 0 );
		}

		break;
		
	case WM_ENTERMENULOOP:
		// Pause the app when menus are displayed
		Pause(TRUE);
		break;
		
	case WM_EXITMENULOOP:
		Pause(FALSE);
		break;
		
	case WM_NCHITTEST:
		// Prevent the user from selecting the menu in fullscreen mode
		if( !m_bWindowed )
			return HTCLIENT;
		break;
		
	case WM_POWERBROADCAST:
		switch( wParam )
		{
#ifndef PBT_APMQUERYSUSPEND
#define PBT_APMQUERYSUSPEND 0x0000
#endif
		case PBT_APMQUERYSUSPEND:
			// At this point, the app should save any data for open
			// network connections, files, etc., and prepare to go into
			// a suspended mode.
			return TRUE;
			
#ifndef PBT_APMRESUMESUSPEND
#define PBT_APMRESUMESUSPEND 0x0007
#endif
		case PBT_APMRESUMESUSPEND:
			// At this point, the app should recover any data, network
			// connections, files, etc., and resume running from when
			// the app was suspended.
			return TRUE;
		}
		break;
		
		case WM_SYSCOMMAND:
		{
			// Prevent moving/sizing and power loss in fullscreen mode
			switch( wParam )
			{
			case SC_MOVE:
			case SC_SIZE:
			case SC_MAXIMIZE:
			case SC_KEYMENU:
			case SC_MONITORPOWER:
				if( FALSE == m_bWindowed )
					return 1;
				break;
			}

			break;
		}

		case WM_COMMAND:
		{
			if(m_dHchagedev && m_dHchagedev == wLo)
			{
				return 0;
			}

			if(m_dHfullscn && m_dHfullscn == wLo)
			{
				Pause( TRUE );
				ToggleFullscreen();
				Pause( FALSE );

				return 0;
			}

			if(m_dHexitm && m_dHexitm == wLo)
			{
				// Recieved key/menu command to exit app
				SendMessage( hWnd, WM_CLOSE, 0, 0 );
				return 0;
			}
			
			break;
		}


		case WM_CLOSE:
		{
			HMENU hMenu;

			Cleanup3DEnvironment();
			
			FinalCleanup();

			if(m_hWnd)
			{
				hMenu = GetMenu(hWnd);
			
				if( hMenu != NULL )
					DestroyMenu( hMenu );
				
				DestroyWindow( hWnd );
				PostQuitMessage(0);
				m_hWnd = NULL;
			}
			return 0;
		}
	}


	return -1;
}


//LRESULT CLnDevD3D9::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
//{
//	switch( msg )
//	{
//		case WM_KEYDOWN:
//		{
//			
//			switch(wParam)
//			{
//				case VK_ESCAPE:
//				{
//					SendMessage(hWnd, WM_DESTROY, 0,0);
//					break;
//				}
//			}
//			
//			break;
//
//		}
//
//		case WM_DESTROY:
//		{
//			PostQuitMessage( 0 );
//			break;
//		}
//	}
//	
//	return DefWindowProc( hWnd, msg, wParam, lParam );
//}


#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"

extern CLnDevD3D9* g_pD3D9App;


HRESULT CD3DApplication::Init()
{
	return S_OK;
}

HRESULT CD3DApplication::Destroy()
{
	g_pD3D9App->Destroy();

	return S_OK;
}


HRESULT CD3DApplication::Restore()
{
	return g_pD3D9App->Restore();
	return S_OK;
}

HRESULT CD3DApplication::Invalidate()
{
	g_pD3D9App->Invalidate();
	return S_OK;
}

HRESULT CD3DApplication::FrameMove()
{
	return g_pD3D9App->FrameMove();
	return S_OK;
}

HRESULT CD3DApplication::Render()
{
	return g_pD3D9App->Render();
	return S_OK;
}