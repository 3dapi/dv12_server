// Implementation of the CLnDevOpenGL class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevOpenGL.h"



CLnDevOpenGL::CLnDevOpenGL()
{
	
}

CLnDevOpenGL::~CLnDevOpenGL()
{
	Destroy();
}

INT CLnDevOpenGL::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnDevOpenGL Create\n");
	return 0;
}

void CLnDevOpenGL::Destroy()
{
	printf("CLnDevOpenGL Destroy\n");
}

INT	CLnDevOpenGL::FrameMove()
{
	printf("CLnDevOpenGL FrameMove\n");
	return 0;
}

INT CLnDevOpenGL::Render()
{
	printf("CLnDevOpenGL Render\n");
	return 0;
}
