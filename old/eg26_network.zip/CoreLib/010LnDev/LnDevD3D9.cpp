// Implementation of the CLnDevD3D9 class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"


#include "D3DxUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLnDevD3D9* g_pD3D9App=NULL;

extern	CD3DApplication g_pD3DApp;


CLnDevD3D9::CLnDevD3D9()
{
	g_pD3D9App		= this;

	m_pd3dApp		= &g_pD3DApp;

	pFuncInit		= NULL;
	pFuncDestroy	= NULL;
	pFuncRestore	= NULL;
	pFuncInvalidate	= NULL;
	pFuncFrameMove	= NULL;
	pFuncRender		= NULL;
}


CLnDevD3D9::~CLnDevD3D9()
{
}

INT CLnDevD3D9::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnDevD3D9 Create\n");

	CD3DApplication*	pd3dApp = (CD3DApplication*)m_pd3dApp;
	LnDev*				pLnDev = (LnDev*)p1;

	HINSTANCE	hInst= (pLnDev->hInst)? pLnDev->hInst: GetModuleHandle(NULL);

	if( strlen(pLnDev->sCls))
	{
		pd3dApp->SetClassName(pLnDev->sCls);
	}

	if(pLnDev->hWnd)
		pd3dApp->SetDxHwnd(pLnDev->hWnd);

	
	pLnDev->hInst = hInst;

	pd3dApp->SetScnPos(pLnDev->PosX, pLnDev->PosY);
	pd3dApp->SetScnSize(pLnDev->ScnX, pLnDev->ScnY);


	if(FAILED(pd3dApp->Create(hInst)))
		return -1;
	
	
	if(pFuncInit)
		return pFuncInit();

	return 0;
}

void CLnDevD3D9::Destroy()
{
	printf("CLnDevD3D9 Destroy\n");

	if(pFuncDestroy)
		pFuncDestroy();
}


INT CLnDevD3D9::Restore()
{
	printf("CLnDevD3D9 Restore\n");

	if(pFuncInit)
		return pFuncRestore();

	return 0;
}

void CLnDevD3D9::Invalidate()
{
	printf("CLnDevD3D9 Invalidate\n");

	if(pFuncInvalidate)
		pFuncInvalidate();
}


INT	CLnDevD3D9::FrameMove()
{
	printf("CLnDevD3D9 FrameMove\n");

	if(pFuncFrameMove)
		return pFuncFrameMove();
	
	return 0;
}

INT CLnDevD3D9::Render()
{
	printf("CLnDevD3D9 Render\n");

	if(pFuncRender)
		return pFuncRender();

	return 0;
}




INT CLnDevD3D9::Query(char* sCmd, void* pData)
{
	printf("CLnDevD3D9 Query:%s\n", sCmd);

	if     (0==_stricmp("SetFuncInit",	 sCmd))		{	pFuncInit		= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncDestoy", sCmd))		{	pFuncDestroy	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncRestore", sCmd))	{	pFuncRestore	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncInvalidate", sCmd))	{	pFuncInvalidate	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncFrameMove", sCmd))	{	pFuncFrameMove	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncRender", sCmd))		{	pFuncRender		= (int (__cdecl *)(void))pData;	return 0;	}

	else if(0==_stricmp("SetScnStyle", sCmd))
	{
		CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
		DWORD	dVal = *((DWORD*)pData);
		pd3dApp->SetScnStyle(dVal);
	}
	else if(0==_stricmp("SetScnIcon", sCmd))
	{
		CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
		DWORD	dVal = *((DWORD*)pData);
		pd3dApp->SetScnIcon(dVal);
	}
	else if(0==_stricmp("SetScnAccelator", sCmd))
	{
		CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
		DWORD	dVal = *((DWORD*)pData);
		pd3dApp->SetScnAccelator(dVal);
	}
	else if(0==_stricmp("SetScnToggle", sCmd))
	{
		CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
		DWORD	dVal = *((DWORD*)pData);
		pd3dApp->SetScnToggle(dVal);
	}

	else if(0==_stricmp("SetScnExit", sCmd))
	{
		CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
		DWORD	dVal = *((DWORD*)pData);
		pd3dApp->SetScnExit(dVal);
	}

	return 0;
}






INT CLnDevD3D9::Run()
{	    
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;

	return pd3dApp->Run();
	return 1;
}




INT CLnDevD3D9::BeginScene()
{
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
	LPDIRECT3DDEVICE9 pDev= pd3dApp->GetDxDevice();

	return pDev->BeginScene();
}

INT CLnDevD3D9::EndScene()
{
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
	LPDIRECT3DDEVICE9 pDev= pd3dApp->GetDxDevice();

	return pDev->EndScene();
}


INT CLnDevD3D9::Clear(DWORD Count,CONST RECT* pRects,DWORD Flags, DWORD Color,float Z,DWORD Stencil)
{
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
	LPDIRECT3DDEVICE9 pDev= pd3dApp->GetDxDevice();

	return pDev->Clear(Count, (D3DRECT*)pRects,Flags,Color,Z,Stencil);
}



INT CLnDevD3D9::SpriteBegin()
{
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
	LPD3DXSPRITE pSpt = pd3dApp->GetDxSprite();

	return pSpt->Begin();
	return 0;
}


INT CLnDevD3D9::SpriteEnd()
{
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
	LPD3DXSPRITE pSpt = pd3dApp->GetDxSprite();

	return pSpt->End();
	return 0;
}


INT CLnDevD3D9::SpriteDraw(void* pTx
						   , CONST RECT* pSrcRect
						   , CONST FLOAT* pScaling
						   , CONST FLOAT* pRotationCenter
						   , FLOAT Rotation
						   , CONST FLOAT* pTranslation
						   , DWORD Color)
{
	LPDIRECT3DTEXTURE9  pSrcTx = (LPDIRECT3DTEXTURE9)pTx;

	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;
	LPD3DXSPRITE pSpt = pd3dApp->GetDxSprite();

	return pSpt->Draw(	pSrcTx
					,	pSrcRect
					,	(D3DXVECTOR2*)pScaling
					,	(D3DXVECTOR2*)pRotationCenter
					,	Rotation
					,	(D3DXVECTOR2*)pTranslation
					,	Color);

	return 0;
}




LPDIRECT3DDEVICE9 CLnDevD3D9::GetDevice()
{
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;

	return pd3dApp->GetDxDevice();
}


LPD3DXSPRITE CLnDevD3D9::GetSprite()
{
	CD3DApplication* pd3dApp = (CD3DApplication*)m_pd3dApp;

	return pd3dApp->GetDxSprite();
}