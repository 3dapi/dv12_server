// Interface for the CLnInputAPI class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnInputAPI_H_
#define _LnInputAPI_H_


class CLnInputAPI : public CLnInputBase
{
protected:
	FLOAT			m_fWheel		;											// Wheel Position

public:
	CLnInputAPI();
	virtual ~CLnInputAPI();

	virtual INT		Create(void* p);
	virtual INT		FrameMove();
	virtual void	SetMousePos(FLOAT* vcPos);

public:
	void			AddWheelPos(INT d);
	LRESULT			MsgProc(HWND,UINT,WPARAM,LPARAM);

protected:
	virtual void	OnReset();
};


#endif