// Interface for the ILnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnInput_H_
#define _ILnInput_H_

#ifndef interface
#define interface struct
#endif




interface ILnInput
{
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;

	
	virtual INT		Query(char* sCmd, void* pData)=0;


	virtual BYTE*	GetKeyMap()	const=0;

	virtual BOOL	KeyDown(INT nKey)=0;
	virtual BOOL	KeyUp(INT nKey)=0;
	virtual BOOL	KeyPress(INT nKey)=0;
	virtual BOOL	KeyState(int nKey)=0;

	virtual BOOL	ButtonDown(INT nBtn)=0;
	virtual BOOL	ButtonUp(INT nBtn)=0;
	virtual BOOL	ButtonPress(INT nBtn)=0;
	virtual BOOL	ButtonState(int nBtn)=0;

	virtual VEC3	GetMousePos()=0;
	virtual VEC3	GetMouseDelta()=0;
	virtual BOOL	GetMouseMove()=0;

	virtual BOOL	IsInRect(INT left, INT top, INT right, INT bottom)=0;
};


INT LnInput_Create(char* sCmd, ILnInput** pData/*in-out value*/, void* p1/*in value*/);


#ifdef _DEBUG
	#pragma comment(lib, "LnInput_.lib")
#else
	#pragma comment(lib, "LnInput.lib")
#endif


#endif

