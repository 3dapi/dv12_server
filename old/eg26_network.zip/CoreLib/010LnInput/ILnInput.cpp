// Implementation of the ILnInputBase class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include <d3d9.h>
#include <d3dx9.h>

#include "../../include/LnLib/LnType.h"

#include "ILnInput.h"
#include "LnInputBase.h"
#include "LnInputAPI.h"
#include "LnInputDirect.h"


INT LnInput_Create(char* sCmd, ILnInput** pData/*in-out value*/, void* p1/*in value*/)
{
	(*pData) = NULL;

	if(0==_stricmp("WinApi", sCmd))
	{
		HWND			hWnd = (HWND)p1;
		CLnInputAPI*	pObj = NULL;

		pObj = new CLnInputAPI;

		if(FAILED(pObj->Create(hWnd)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Direct", sCmd))
	{
		PDEV			hDev = (PDEV)p1;
		CLnInputDirect* pObj = NULL;

		pObj	= new CLnInputDirect;

		if(FAILED(pObj->Create(hDev)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	return -1;
}
