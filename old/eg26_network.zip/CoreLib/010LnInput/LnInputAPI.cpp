// Implementation of the CLnInputAPI class.
//
////////////////////////////////////////////////////////////////////////////////

#define _WIN32_WINNT			0x0400

#include <windows.h>
#include <d3dx9.h>

#include "../../include/LnLib/LnType.h"

#include "ILnInput.h"
#include "LnInputBase.h"
#include "LnInputAPI.h"


CLnInputAPI::CLnInputAPI()
{
	m_eType		= LN_INPUT_API;
	m_fWheel	= 0.f;
}

CLnInputAPI::~CLnInputAPI()
{
}


INT CLnInputAPI::Create(void* p)
{
	m_hWnd =(HWND)p;
	return 1;
}

INT CLnInputAPI::FrameMove()
{
	int i;
	POINT pt;

	memcpy(m_KeyOld, m_KeyCur, sizeof m_KeyOld);
	memcpy(m_vcMsOld, m_vcMsCur, sizeof m_vcMsCur);

	memset(m_KeyCur,		0, sizeof m_KeyCur);
	memset(m_KeyMap,		0, sizeof m_KeyMap);
	memset(m_BtnMap,		0, sizeof m_BtnMap);

	GetKeyboardState(m_KeyCur);

	for(i=0; i<256; ++i)
	{
		m_KeyCur[i] = (m_KeyCur[i] & 0x80)? 1: 0;

		INT nOld = m_KeyOld[i];
		INT nCur = m_KeyCur[i];

		if		(0 == nOld && 1 ==nCur)	m_KeyMap[i] = 1;		// Down
		else if	(1 == nOld && 0 ==nCur)	m_KeyMap[i] = 2;		// Up
		else if	(1 == nOld && 1 ==nCur)	m_KeyMap[i] = 3;		// Press
	}

	m_BtnMap[0] = m_KeyMap[VK_LBUTTON];
	m_BtnMap[1] = m_KeyMap[VK_RBUTTON];
	m_BtnMap[2] = m_KeyMap[VK_MBUTTON];


	::GetCursorPos(&pt);
	::ScreenToClient( m_hWnd, &pt);
	
	m_vcMsCur.x	= FLOAT(pt.x);
	m_vcMsCur.y	= FLOAT(pt.y);
	m_vcMsCur.z	+= m_fWheel;
	
	m_vcDelta	= m_vcMsCur- m_vcMsOld;
	m_fWheel	= 0.f;

	return 1;
}


void CLnInputAPI::AddWheelPos(INT d)
{
	m_fWheel = FLOAT(d);
}



void CLnInputAPI::SetMousePos(FLOAT* vcPos)
{
	m_vcMsCur.x = vcPos[0];
	m_vcMsCur.y = vcPos[1];
	m_vcMsCur.z = vcPos[2];

	FLOAT x= vcPos[0];
	FLOAT y= vcPos[1];

	RECT rc;
	ClientRect(m_hWnd, &rc);

	x += rc.left;
	y += rc.top;
	
//	POINT pt;
//	pt.x = x;
//	pt.y = y;
//	::ScreenToClient( m_hWnd, &pt);
	SetCursorPos(x, y);	
}



void CLnInputAPI::OnReset()
{
	SetKeyboardState(m_KeyCur);
	m_fWheel = 0;
}




LRESULT CLnInputAPI::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_MOUSEWHEEL:
		{
			AddWheelPos( SHORT( HIWORD(wParam) ));
			break;
		}
	}
	
	return FALSE;
}