// Implementation of the CLnInputDirect class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "../../include/LnLib/LnType.h"

#include "ILnInput.h"
#include "LnInputBase.h"
#include "LnInputAPI.h"
#include "LnInputDirect.h"


#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p) {	if(p){	(p)->Release();		(p) = NULL;	}	}
#endif


CLnInputDirect::CLnInputDirect()
{
	m_eType		= LN_INPUT_DIRECT;

	memset(m_BtnCur,		0, sizeof m_BtnCur);
	memset(m_BtnOld,		0, sizeof m_BtnOld);
}

CLnInputDirect::~CLnInputDirect()
{
}


INT CLnInputDirect::Create(void* pDev)
{
	D3DDEVICE_CREATION_PARAMETERS d3Parameter;

	m_hInst = (HINSTANCE) GetModuleHandle(NULL);
	m_pDev = (PDEV)pDev;

	m_pDev->GetCreationParameters(&d3Parameter);
	m_hWnd = d3Parameter.hFocusWindow;

	if(FAILED(InitDInput()))
		return -1;

	POINT pt;
	::GetCursorPos(&pt);
	::ScreenToClient( m_hWnd, &pt);
	m_pDev->SetCursorPosition( pt.x, pt.y, 0 );

	m_vcMsCur.x  = FLOAT(pt.x);
	m_vcMsCur.y  = FLOAT(pt.y);

	return 1;
}


INT CLnInputDirect::FrameMove()
{
	int i=0;
		
	memcpy(m_KeyOld, m_KeyCur, sizeof m_KeyOld);
	memcpy(m_BtnOld, m_BtnCur, sizeof m_BtnOld);
	memcpy(m_vcMsOld, m_vcMsCur, sizeof m_vcMsCur);

	memset(m_KeyCur,		0, sizeof m_KeyCur);
	memset(m_KeyMap,		0, sizeof m_KeyMap);
	
	memset(m_BtnCur,		0, sizeof m_BtnCur);
	memset(m_BtnMap,		0, sizeof m_BtnMap);

	UpdateDInput();


	for(i=0; i<256; ++i)
	{
		m_KeyCur[i] = (m_KeyCur[i] & 0x80)? 1: 0;

		INT nOld = m_KeyOld[i];
		INT nCur = m_KeyCur[i];

		if		(0 == nOld && 1 ==nCur)	m_KeyMap[i] = 1;		// Down
		else if	(1 == nOld && 0 ==nCur)	m_KeyMap[i] = 2;		// Up
		else if	(1 == nOld && 1 ==nCur)	m_KeyMap[i] = 3;		// Press
	}


	m_BtnCur[0]	= m_MsSt.rgbButtons[0] ? 1: 0;
	m_BtnCur[1]	= m_MsSt.rgbButtons[1] ? 1: 0;
	m_BtnCur[2]	= m_MsSt.rgbButtons[2] ? 1: 0;


	for(i=0; i<8; ++i)
	{
		INT nOld = m_BtnOld[i];
		INT nCur = m_BtnCur[i];

		if		(0 == nOld && 1 ==nCur)	m_BtnMap[i] = 1;		// Down
		else if	(1 == nOld && 0 ==nCur)	m_BtnMap[i] = 2;		// Up
		else if	(1 == nOld && 1 ==nCur)	m_BtnMap[i] = 3;		// Press
	}


//	POINT pt;
//	::GetCursorPos(&pt);
//	::ScreenToClient( m_hWnd, &pt);
//	m_pDev->SetCursorPosition( pt.x, pt.y, 0 );
//
//	m_vcMsCur.x  = FLOAT(pt.x);
//	m_vcMsCur.y  = FLOAT(pt.y);
//
	m_vcMsCur.x += FLOAT(m_MsSt.lX);
	m_vcMsCur.y += FLOAT(m_MsSt.lY);
	m_vcMsCur.z += FLOAT(m_MsSt.lZ);

	m_vcDelta	= m_vcMsCur- m_vcMsOld;




	return 1;
}





INT CLnInputDirect::InitDInput()
{
	DWORD		flags = DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY;

	// Keyboard
	if (FAILED(DirectInput8Create(	m_hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void **)&m_pDInput, NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDiKey, NULL)))
		return -1;
	
	if (FAILED(m_pDiKey->SetDataFormat(&c_dfDIKeyboard)))
		return -1;
	
	if (FAILED(m_pDiKey->SetCooperativeLevel(m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
		return -1;


	// Mouse
	if (FAILED(DirectInput8Create(	m_hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void **)&m_pDInput, NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDiMs, NULL)))
		return -1;
	
	if (FAILED(m_pDiMs->SetDataFormat(&c_dfDIMouse)))
		return -1;
	
	if (FAILED(m_pDiMs->SetCooperativeLevel(m_hWnd, flags)))
		return -1;

	
	
	return 1;
}



INT CLnInputDirect::UpdateDInput()
{
	// Keyboard
	if (FAILED(m_pDiKey->GetDeviceState(sizeof m_KeyCur, (LPVOID)m_KeyCur)))
	{
		memset(m_KeyCur, 0, sizeof m_KeyCur);
		
		if (FAILED(m_pDiKey->Acquire()))
			return -1;
		
		if (FAILED(m_pDiKey->GetDeviceState(sizeof m_KeyCur, (LPVOID)m_KeyCur)))
			return -1;
	}


	// Mouse
	if (FAILED(m_pDiMs->GetDeviceState(sizeof m_MsSt, &m_MsSt)))
	{
		if (FAILED(m_pDiMs->Acquire()))
			return -1;
		
		if (FAILED(m_pDiMs->GetDeviceState(sizeof m_MsSt, &m_MsSt)))
			return -1;
	}
	
	return 1;
}



void CLnInputDirect::SetMousePos(FLOAT* vcPos)
{
	m_vcMsCur.x = vcPos[0];
	m_vcMsCur.y = vcPos[1];
	m_vcMsCur.z = vcPos[2];

	FLOAT x= vcPos[0];
	FLOAT y= vcPos[1];

//	m_pDev->SetCursorPosition( x, y, 0 );

	RECT rc;
	ClientRect(m_hWnd, &rc);
	x += rc.left;
	y += rc.top;
	SetCursorPos(x, y);

	m_pDev->SetCursorPosition( x, y, D3DCURSOR_IMMEDIATE_UPDATE );
}



void CLnInputDirect::OnReset()
{
}
