// Interface for the CLnInputBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnInputBase_H_
#define _LnInputBase_H_


class CLnInputBase : public ILnInput
{
public:
	enum ELnInput
	{
		LN_INPUT_0,
		LN_INPUT_API,
		LN_INPUT_DIRECT,
	};
	
protected:
	ELnInput		m_eType			;											// Input Type
	HINSTANCE		m_hInst			;											// HINSTANCE
	HWND			m_hWnd			;											// Window Handle

	BYTE			m_KeyCur[256]	;											// Current Keyboard
	BYTE			m_KeyOld[256]	;											// Old Keyboard
	
	BYTE			m_KeyMap[256]	;											// Key Map down: 1, up: 2, Press 3
	BYTE			m_BtnMap[8]		;											// Button Map

	VEC3			m_vcMsCur		;											// Mouse Current Position
	VEC3			m_vcMsOld		;											// Mouse Old Position
	VEC3			m_vcDelta		;											// Delta Mouse Position


public:
	CLnInputBase();
	virtual ~CLnInputBase();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);


	virtual BYTE*	GetKeyMap()	const;

	virtual BOOL	KeyDown(INT nKey);
	virtual BOOL	KeyUp(INT nKey);
	virtual BOOL	KeyPress(INT nKey);
	virtual BOOL	KeyState(int nKey);

	virtual BOOL	ButtonDown(INT nBtn);
	virtual BOOL	ButtonUp(INT nBtn);
	virtual BOOL	ButtonPress(INT nBtn);
	virtual BOOL	ButtonState(int nBtn);

	virtual VEC3	GetMousePos();
	virtual VEC3	GetMouseDelta();
	virtual BOOL	GetMouseMove();

	virtual BOOL	IsInRect(INT left, INT top, INT right, INT bottom);

protected:
	void	ClientRect(HWND hWnd, RECT* rc);
};

#endif
