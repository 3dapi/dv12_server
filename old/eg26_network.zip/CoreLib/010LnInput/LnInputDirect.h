// Interface for the CLnInputDirect class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnInputDirect_H_
#define _LnInputDirect_H_


#define DIRECTINPUT_VERSION	0x0800
#include <dinput.h>


class CLnInputDirect : public CLnInputBase
{
protected:
	PDEV					m_pDev		;										// Device

	LPDIRECTINPUT8			m_pDInput	;										// Dinput
	LPDIRECTINPUTDEVICE8	m_pDiKey	;										// Keyboard
	LPDIRECTINPUTDEVICE8	m_pDiMs		;										// Mouse
	DIMOUSESTATE			m_MsSt		;										// Mouse State

	BYTE					m_BtnCur[8]	;										// Button Old
	BYTE					m_BtnOld[8]	;										// Button Current

public:
	CLnInputDirect();
	virtual ~CLnInputDirect();
	
	virtual INT		Create(void* p);
	virtual INT		FrameMove();
	virtual void	SetMousePos(FLOAT* vcPos);
	
protected:
	INT		InitDInput();
	INT		UpdateDInput();
	virtual void	OnReset();
};

#endif