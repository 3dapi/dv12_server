// Implementation of the CLnInputBase class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "../../include/LnLib/LnType.h"

#include "ILnInput.h"
#include "LnInputBase.h"



CLnInputBase::CLnInputBase()
{
	m_eType		= LN_INPUT_0;
	m_hWnd		= NULL;

	memset(  m_KeyCur, 0, sizeof  m_KeyCur);
	memset(  m_KeyOld, 0, sizeof  m_KeyOld);

	memset(  m_KeyMap, 0, sizeof  m_KeyMap);
	memset(  m_BtnMap, 0, sizeof  m_BtnMap);

	memset(&m_vcMsCur, 0, sizeof m_vcMsCur);
	memset(&m_vcMsOld, 0, sizeof m_vcMsOld);
	memset(&m_vcDelta, 0, sizeof m_vcDelta);
}

CLnInputBase::~CLnInputBase()
{
	Destroy();
}


INT CLnInputBase::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnInputBase Create\n");
	return 0;
}

void CLnInputBase::Destroy()
{
	printf("CLnInputBase Destroy\n");
}

INT	CLnInputBase::FrameMove()
{
	printf("CLnInputBase FrameMove\n");
	return 0;
}

void CLnInputBase::Render()
{
	printf("CLnInputBase Render\n");
}


INT CLnInputBase::Query(char* sCmd, void* pData)
{
	printf("CLnInputBase Query:%s\n", sCmd);
	return 0;
}






BYTE* CLnInputBase::GetKeyMap() const
{
	return (BYTE*)m_KeyMap;
}



BOOL CLnInputBase::KeyDown(INT nKey)
{
	return (1 == m_KeyMap[nKey])? 1: 0;
}

BOOL CLnInputBase::KeyUp(INT nKey)
{
	return (2 == m_KeyMap[nKey])? 1: 0;
}

BOOL CLnInputBase::KeyPress(INT nKey)
{
	return (3 == m_KeyMap[nKey])? 1: 0;
}

BOOL CLnInputBase::KeyState(int nKey)
{
	return m_KeyMap[nKey];
}



BOOL CLnInputBase::ButtonDown(INT nBtn)
{
	return (1 == m_BtnMap[nBtn])? 1: 0;
}

BOOL CLnInputBase::ButtonUp(INT nBtn)
{
	return (2 == m_BtnMap[nBtn])? 1: 0;
}

BOOL CLnInputBase::ButtonPress(INT nBtn)
{
	return (3 == m_BtnMap[nBtn])? 1: 0;
}


BOOL CLnInputBase::ButtonState(int nBtn)
{
	return m_BtnMap[nBtn];
}


VEC3 CLnInputBase::GetMousePos()
{
	return m_vcMsCur;
}

VEC3 CLnInputBase::GetMouseDelta()
{
	return m_vcDelta;
}


BOOL CLnInputBase::GetMouseMove()
{
	return (m_vcMsCur != m_vcMsOld) ? 1: 0;
}


BOOL CLnInputBase::IsInRect(INT left, INT top, INT right, INT bottom)
{
	return (	m_vcMsCur.x>=left
			&&	m_vcMsCur.y>=top
			&&	m_vcMsCur.x<=right
			&&	m_vcMsCur.y<=bottom);
}




void CLnInputBase::ClientRect(HWND hWnd, RECT* rc)
{
	RECT rc1;
	RECT rc2;
	INT FrmW;
	INT FrmH;

	::GetWindowRect(hWnd, &rc1);
	::GetClientRect(hWnd, &rc2);

	FrmW = (rc1.right - rc1.left - rc2.right)/2;
	FrmH = rc1.bottom - rc1.top - rc2.bottom - FrmW;

	// Window Client Rect ���� ��ġ
	rc->left = rc1.left + FrmW;
	rc->top  = rc1.top  + FrmH;

	// Window Client Rect Width and Height
	rc->right	= rc2.right+ rc2.left;
	rc->bottom	= rc2.bottom+ rc2.top;
}


