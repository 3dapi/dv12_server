// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "include/LnLib/LnType.h"
#include "include/LnLib/ILnDev.h"

#include "include/LnLib/ILnTex.h"
#include "Main.h"

#include "resource.h"


CMain*	g_pAppMain;

extern ILnDev*	g_pDev;




INT CMain::pFuncInit()
{
	if(g_pAppMain)
		return g_pAppMain->Init();

	return 0;
}

void CMain::pFuncDestroy()
{
	if(g_pAppMain)
		g_pAppMain->Destroy();
}

INT CMain::pFuncRestore()
{
	if(g_pAppMain)
		return g_pAppMain->Restore();
	
	return 0;
}

void CMain::pFuncInvalidate()
{
	if(g_pAppMain)
		g_pAppMain->Invalidate();
}

INT CMain::pFuncFrameMove()
{
	if(g_pAppMain)
		return g_pAppMain->FrameMove();
	
	return 0;
}

void CMain::pFuncRender()
{
	if(g_pAppMain)
		g_pAppMain->Render();
}



CMain::CMain()
{
	g_pAppMain = this;

	m_MngTx	= NULL;
	m_pTx	= NULL;


	printf("\n���� �غ�--------------------\n");
	LnDev_CreateDevice("Create Direct3D9", &g_pDev);

	g_pDev->Query("SetFuncInit", CMain::pFuncInit);
	g_pDev->Query("SetFuncDestoy", CMain::pFuncDestroy);
	g_pDev->Query("SetFuncRestore", CMain::pFuncRestore);
	g_pDev->Query("SetFuncInvalidate", CMain::pFuncInvalidate);
	g_pDev->Query("SetFuncFrameMove", CMain::pFuncFrameMove);
	g_pDev->Query("SetFuncRender", CMain::pFuncRender);


	g_pDev->Query("SetFuncRender", CMain::pFuncRender);

	DWORD dIcon		= IDI_MAIN_ICON;
	DWORD dAccel	= IDR_MAIN_ACCEL;
	DWORD dToggle	= IDM_TOGGLEFULLSCREEN;
	DWORD dExit		= IDM_EXIT;
	DWORD dStyle	= WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_VISIBLE|WS_MINIMIZEBOX | WS_MAXIMIZEBOX;

	g_pDev->Query("SetScnStyle", &dStyle);
	g_pDev->Query("SetScnIcon", &dIcon);
	g_pDev->Query("SetScnAccelator", &dAccel);
	g_pDev->Query("SetScnToggle", &dToggle);
	g_pDev->Query("SetScnExit", &dExit);

}


CMain::~CMain()
{
}


INT CMain::Init()
{
	INT hr=-1;

	m_pDev	= (LPDIRECT3DDEVICE9)LnDev_GetD3Device(&g_pDev);

	hr = LnTex_CreateTexMng(m_pDev, &m_MngTx);

	m_MngTx->FindCreate("File", &m_pTx, "dx5_logo.bmp");
	m_MngTx->FindCreate("File", &m_pTx, "dx5_logo.bmp");
	m_MngTx->FindCreate("File", &m_pTx, "dx5_logo.bmp");
	
	return 0;
}

void CMain::Destroy()
{
	printf("Call CMain::Destroy()\n");

	if(m_MngTx)
	{
		m_MngTx->Destroy();
		delete m_MngTx;
		m_MngTx = NULL;
	}
}


INT CMain::Restore()
{
	printf("Call CMain::Restore()\n");

	return 0;
}


void  CMain::Invalidate()
{
	printf("Call CMain::Invalidate()\n");
}


INT  CMain::FrameMove()
{
	static int c=0;

	if(++c>100)
	{
//		return -1;
	}

	printf("Call CMain::FrameMove(%d)\n", c);
	
	return 0;
}


void  CMain::Render()
{
	g_pDev->BeginScene();

	printf("Call CMain::Render()\n");

	g_pDev->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0XFF006699, 1, 0L);

	RECT rc={0};
	rc.right = m_pTx->GetWidth();
	rc.bottom= m_pTx->GetHeight();
	void* pTx = m_pTx->GetTex();

	D3DXVECTOR2	vcP(200, 100);
	
	g_pDev->SpriteDraw(pTx, &rc, NULL, NULL, 0, (FLOAT*)&vcP, 0XFFFFFFFF);

	g_pDev->EndScene();
}