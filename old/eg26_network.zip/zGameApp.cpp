
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "include/LnLib/LnType.h"
#include "include/LnLib/ILnDev.h"

#include "include/LnLib/ILnTex.h"
#include "Main.h"


// MainŬ���� �ν��Ͻ�
CMain*	g_pApp=NULL;
ILnDev*	g_pDev;

void main()
{
	CMain	mainApp;
	g_pApp	= &mainApp;

	printf("\n\n���� ����--------------------\n");

	LnDev	sDev(-1, -1, 1024, 768, "LnEngineApp1");
	g_pDev->Create(&sDev);
	
	g_pDev->Run();

	delete g_pDev;

	printf("\n���� ����--------------------\n");
	
	printf("\n");

	return;
}




