// Interface for the CLnNetBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetBase_H_
#define _LnNetBase_H_


class CLnNetBase : public ILnNet
{
public:
	enum ELnNetPrtcl
	{
		NETPT_NONE	=0,					// NONE
		NETPT_TCP	=1,					// TCP
		NETPT_UDP	=2,					// UDP
	};

	enum ELnNetHstType
	{
		NETHST_NONE		=0,				// NONE
		NETHST_CLIENT	=1,				// Client
		NETHST_SERVER	=2,				// Server
	};

protected:
	SOCKET		m_scH;					// ȣ��Ʈ ����
	SOCKADDR_IN	m_sdH;					// ȣ��Ʈ ��巹��
	char		m_sIp[32];				// IP
	char		m_sPt[16];				// Port

	BOOL		m_bConn;				// Is Connect?

	INT			m_PtcType;				// Protocol type
	INT			m_HstType;				// Client Server?



public:
	CLnNetBase();
	virtual ~CLnNetBase();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Close();
	virtual INT		Listen();
	virtual INT		Accept();
	virtual INT		Connect(char* sIp=NULL, char* sPort=NULL);

	virtual INT		Send(char* sBuf, INT* iSnd);
	virtual INT		Recv(char* sBuf, INT* iRcv);

	virtual INT		IsConnect();
public:

};

#endif
