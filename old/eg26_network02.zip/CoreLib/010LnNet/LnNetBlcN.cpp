// Implementation of the CLnNetBlcN class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"
#include "LnNetBlcN.h"



CLnNetBlcN::CLnNetBlcN()
{
}


CLnNetBlcN::~CLnNetBlcN()
{
}


INT CLnNetBlcN::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetBlcN Create\n");

	return 0;
}


void CLnNetBlcN::Destroy()
{
	printf("CLnNetBlcN Destroy\n");
}


INT	CLnNetBlcN::FrameMove()
{
	printf("CLnNetBlcN FrameMove\n");

	return 0;
}


INT CLnNetBlcN::Query(char* sCmd, void* pData)
{
	printf("CLnNetBlcN Query:%s\n", sCmd);

	if(0==_stricmp("Query", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}

