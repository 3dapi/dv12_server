// Implementation of the CLnNetOvrl class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"
#include "LnNetOvrl.h"



CLnNetOvrl::CLnNetOvrl()
{
}


CLnNetOvrl::~CLnNetOvrl()
{
}

INT CLnNetOvrl::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetOvrl Create\n");

	return 0;
}

void CLnNetOvrl::Destroy()
{
	printf("CLnNetOvrl Destroy\n");
}


INT	CLnNetOvrl::FrameMove()
{
	printf("CLnNetOvrl FrameMove\n");

	return 0;
}


INT CLnNetOvrl::Query(char* sCmd, void* pData)
{
	printf("CLnNetOvrl Query:%s\n", sCmd);

	if(0==_stricmp("Query", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}


