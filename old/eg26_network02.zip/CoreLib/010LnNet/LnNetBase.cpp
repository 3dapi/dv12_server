// Implementation of the CLnNetBase class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"


CLnNetBase::CLnNetBase()
{
	m_scH		= 0;
	memset(&m_sdH, 0, sizeof m_sdH);
	memset(m_sIp, 0, sizeof m_sdH);
	memset(m_sPt, 0, sizeof m_sPt);

	m_bConn		= FALSE;

	m_PtcType	= NETPT_NONE;		// Protocol type
	m_HstType	= NETHST_NONE;		// Client Server?
}

CLnNetBase::~CLnNetBase()
{
	Destroy();
}


INT CLnNetBase::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetBase Create\n");

	return 0;
}


void CLnNetBase::Destroy()
{
	printf("CLnNetBase Destroy\n");
}


INT	CLnNetBase::FrameMove()
{
	printf("CLnNetBase FrameMove\n");
	return 0;
}


INT CLnNetBase::Query(char* sCmd, void* pData)
{
	printf("CLnNetBase Query:%s\n", sCmd);
	return 0;
}




INT CLnNetBase::Close()
{
	return 0;
}

INT CLnNetBase::Listen()
{
	return 0;
}


INT CLnNetBase::Accept()
{
	return 0;
}


INT CLnNetBase::Connect(char* sIp, char* sPort)
{
	return 0;
}


INT CLnNetBase::Send(char* sBuf, INT* iSnd)
{
	return 0;
}

INT CLnNetBase::Recv(char* sBuf, INT* iRcv)
{
	return 0;
}

INT CLnNetBase::IsConnect()
{
	return m_bConn;
}