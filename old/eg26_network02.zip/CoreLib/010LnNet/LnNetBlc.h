// Interface for the CLnNetBlc class.
// Network I/O Blocking
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetBlc_H_
#define _LnNetBlc_H_


class CLnNetBlc : public CLnNetBase
{
protected:

public:
	CLnNetBlc();
	virtual ~CLnNetBlc();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Close();
	virtual INT		Listen();
	virtual INT		Accept();
	virtual INT		Connect(char* sIp=NULL, char* sPort=NULL);

	virtual INT		Send(char* sBuf, INT* iSnd);
	virtual INT		Recv(char* sBuf, INT* iRcv);

protected:

};

#endif