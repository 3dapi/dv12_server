// Server Application
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>


#include "../include/LnLib/ILnNet.h"


ILnNet*		g_pNet=NULL;				// Network Instance


void main()
{
	printf("\n��Ʈ��ũ �غ�--------------------\n");

	if(FAILED(LnNet_CreateTcpServer("Blocking", &g_pNet, NULL, "20000")))
		return;


	printf("\n\n��Ʈ��ũ ����--------------------\n");
	g_pNet->FrameMove();
	delete g_pNet;

	printf("\n��Ʈ��ũ ����--------------------\n\n");

	return;
}

