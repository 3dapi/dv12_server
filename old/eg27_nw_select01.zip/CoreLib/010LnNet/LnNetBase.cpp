// Implementation of the CLnNetBase class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"


CLnNetBase::CLnNetBase()
{
	m_scH		= 0;
	memset(&m_sdH, 0, sizeof m_sdH);
	memset(m_sIp, 0, sizeof m_sdH);
	memset(m_sPt, 0, sizeof m_sPt);

	m_nConn		= 0;

	m_PtcType	= NETPT_NONE;		// Protocol type
	m_HstType	= NETHST_NONE;		// Client Server?

	m_hThSend	= 0;
	m_dThSend	= 0;
	m_nThSend	= 0;

	m_hThRecv	= 0;
	m_dThRecv	= 0;
	m_nThRecv	= 0;

	m_hThAccp	= 0;
	m_dThAccp	= 0;
	m_nThAccp	= 0;
}

CLnNetBase::~CLnNetBase()
{
	Destroy();
}


INT CLnNetBase::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetBase Create\n");

	return 0;
}


void CLnNetBase::Destroy()
{
	printf("CLnNetBase Destroy\n");
}


INT CLnNetBase::FrameMove()
{
	printf("CLnNetBase FrameMove\n");
	return 0;
}


INT CLnNetBase::Query(char* sCmd, void* pData)
{
	printf("CLnNetBase Query:%s\n", sCmd);
	return 0;
}




INT CLnNetBase::Close()
{
	return 0;
}

INT CLnNetBase::Listen()
{
	return 0;
}


INT CLnNetBase::Connect(char* sIp, char* sPort)
{
	return 0;
}


INT CLnNetBase::Send(char* sSrc, INT* iSnd, SOCKET* scH)
{
	return 0;
}

INT CLnNetBase::Recv(char* sDst, INT* iRcv, SOCKET* scH)
{
	return 0;
}

INT CLnNetBase::IsConnect()
{
	return m_nConn;
}




DWORD WINAPI CLnNetBase::ThreadRecv(void* pParam)
{
	return ((CLnNetBase*)pParam)->ProcRecv(pParam);
}


DWORD WINAPI CLnNetBase::ThreadSend(void* pParam)
{
	return ((CLnNetBase*)pParam)->ProcSend(pParam);
}


DWORD WINAPI CLnNetBase::ThreadAccp(void* pParam)
{
	return ((CLnNetBase*)pParam)->ProcAccp(pParam);
}


DWORD CLnNetBase::ProcRecv(void* pParam)
{
	printf("CLnNetBase:ProcRecv\n");
	return 0;
}


DWORD CLnNetBase::ProcSend(void* pParam)
{
	printf("CLnNetBase:ProcSend\n");
	return 0;
}

DWORD CLnNetBase::ProcAccp(void* pParam)
{
	printf("CLnNetBase:ProcAccept\n");
	return 0;
}