// Interface for the CLnNetBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetBase_H_
#define _LnNetBase_H_


class CLnNetBase : public ILnNet
{
public:
	enum ELnNetPrtcl
	{
		NETPT_NONE	=0,					// NONE
		NETPT_TCP	=1,					// TCP
		NETPT_UDP	=2,					// UDP
	};

	enum ELnNetHstType
	{
		NETHST_NONE		=0,				// NONE
		NETHST_CLIENT	=1,				// Client
		NETHST_SERVER	=2,				// Server
	};

protected:
	SOCKET		m_scH;					// ȣ��Ʈ ����
	SOCKADDR_IN	m_sdH;					// ȣ��Ʈ ��巹��
	char		m_sIp[32];				// IP
	char		m_sPt[16];				// Port

	INT			m_nConn;				// Is Connect?

	INT			m_PtcType;				// Protocol type
	INT			m_HstType;				// Client Server?


	HANDLE		m_hThRecv;
	DWORD		m_dThRecv;
	INT			m_nThRecv;				// Recv Thread State

	HANDLE		m_hThSend;				// Thread Handle
	DWORD		m_dThSend;
	INT			m_nThSend;				// Send Thread State

	HANDLE		m_hThAccp;
	DWORD		m_dThAccp;
	INT			m_nThAccp;				// Accept Thread State

public:
	CLnNetBase();
	virtual ~CLnNetBase();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Close();
	virtual INT		Listen();
	virtual INT		Connect(char* sIp=NULL, char* sPort=NULL);

	virtual INT		Send(char* sSrc, INT* iSnd, SOCKET* scH=NULL);
	virtual INT		Recv(char* sDst, INT* iRcv, SOCKET* scH=NULL);

	virtual INT		IsConnect();
public:


	static DWORD WINAPI ThreadRecv(void* pParam);		// Receive�� ������
	static DWORD WINAPI ThreadSend(void* pParam);		// Send�� ������
	static DWORD WINAPI ThreadAccp(void* pParam);		// Accept�� ������

	virtual DWORD	ProcRecv(void* pParam);
	virtual DWORD	ProcSend(void* pParam);
	virtual DWORD	ProcAccp(void* pParam);
};

#endif
