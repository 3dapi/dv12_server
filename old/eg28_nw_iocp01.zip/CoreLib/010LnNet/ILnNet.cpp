// Implementation of the ILnNet class.
//
////////////////////////////////////////////////////////////////////////////////


#include <WINSOCK2.H>
#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"

#include "LnNetUtil.h"
#include "LnNetBase.h"

#include "LnNetBlc.h"
#include "LnNetBlcN.h"
#include "LnNetSlct.h"
#include "LnNetSlctA.h"
#include "LnNetSlctE.h"
#include "LnNetOvrl.h"
#include "LnNetIocp.h"


INT LnNet_Create(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 , void* p3			// TCP: "TCP" , UDP: "UDP"
				 , void* p4			// Server: "Server", Client: "Client"
				 );




INT LnNet_CreateTcpServer(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 )
{
	return LnNet_Create(sCmd, pData, p1, p2, "TCP", "Server");
}

INT LnNet_CreateTcpClient(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 )
{
	return LnNet_Create(sCmd, pData, p1, p2, "TCP", "Client");
}








INT LnNet_Create(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 , void* p3			// TCP: "TCP" , UDP: "UDP"
				 , void* p4			// Server: "Server", Client: "Client"
				 )
{
	(*pData) = NULL;

	if(0==_stricmp("Blocking", sCmd))
	{
		CLnNetBlc* pObj = NULL;

		pObj = new CLnNetBlc;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;		
		return 0;
	}

	else if(0==_stricmp("Non Blocking", sCmd))
	{
		CLnNetBlcN* pObj = NULL;
		pObj = new CLnNetBlcN;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Select", sCmd))
	{
		CLnNetSlct* pObj = NULL;
		pObj = new CLnNetSlct;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Async Select", sCmd))
	{
		CLnNetSlctA* pObj = NULL;
		pObj = new CLnNetSlctA;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Event Select", sCmd))
	{
		CLnNetSlctE* pObj = NULL;
		pObj = new CLnNetSlctE;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Overlapped IO", sCmd))
	{
		CLnNetOvrl* pObj = NULL;
		pObj = new CLnNetOvrl;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("IOCP", sCmd))
	{
		CLnNetIocp* pObj = NULL;
		pObj = new CLnNetIocp;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	return -1;
}


