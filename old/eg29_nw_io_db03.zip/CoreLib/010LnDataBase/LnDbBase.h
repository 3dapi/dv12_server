// Interface for the CLnDbBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDbBase_H_
#define _LnDbBase_H_


class CLnDbBase : public ILnDataBase
{
protected:

public:	
	CLnDbBase();
	virtual ~CLnDbBase();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();
	virtual	INT		Query(char* sCmd, void* pData);


	virtual INT		Connect(void* pDataType, void* p1=0, void* p2=0, void* p3=0);
	virtual void	Close();

	virtual INT		SqlBind(char* sSQL, char*** sOutputBufc,INT** nDataBufc, INT nBufSize);
	virtual INT		SqlExec();
	virtual INT		SqlClose();	
};


#endif


