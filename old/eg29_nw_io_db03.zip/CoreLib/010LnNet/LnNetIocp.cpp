// Implementation of the CLnNetIocp class.
//
////////////////////////////////////////////////////////////////////////////////

#include <WINSOCK2.H>
#include <windows.h>
#include <stdio.h>

#include "LnNetUtil.h"
#include "ILnNet.h"

#include "LnNetUtil.h"
#include "LnNetBase.h"
#include "LnNetIocp.h"



CLnNetIocp::LnNetIocpHost::LnNetIocpHost()
{
	scH = 0;
	memset(&sdH  , 0, sizeof(sdH)  );

	memset(&olRcv, 0, sizeof(olRcv));
	memset(&wsRcv, 0, sizeof(wsRcv));
	memset(sRcv  , 0, sizeof(sRcv ));

	memset(&olSnd, 0, sizeof(olSnd));
	memset(&wsSnd, 0, sizeof(wsSnd));
	memset(sSnd  , 0, sizeof(sSnd ));

	wsRcv.buf=(char*)sRcv;
	wsRcv.len=sizeof(sRcv);

	wsSnd.buf=(char*)sSnd;
	wsSnd.len=sizeof(sSnd);

	olRcv.nEvt = NETEVT_RECV;
	olSnd.nEvt = NETEVT_SEND;
}

CLnNetIocp::LnNetIocpHost::LnNetIocpHost(SOCKET _scH, SOCKADDR_IN* _sdH)
{
	scH= _scH;
	memcpy(&sdH, _sdH, sizeof sdH);

	memset(&olRcv, 0, sizeof(olRcv));
	memset(&wsRcv, 0, sizeof(wsRcv));
	memset(sRcv  , 0, sizeof(sRcv ));

	memset(&olSnd, 0, sizeof(olSnd));
	memset(&wsSnd, 0, sizeof(wsSnd));
	memset(sSnd  , 0, sizeof(sSnd ));

	wsRcv.buf=(char*)sRcv;
	wsRcv.len=sizeof(sRcv);

	wsSnd.buf=(char*)sSnd;
	wsSnd.len=sizeof(sSnd);
	
	olRcv.nEvt = NETEVT_RECV;
	olSnd.nEvt = NETEVT_SEND;
}



void CLnNetIocp::LnNetIocpHost::Destroy()
{
	LnNet_SocketClose(&scH);

	scH = 0;
	memset(&sdH  , 0, sizeof(sdH)  );

	memset(&olRcv, 0, sizeof(olRcv));
	memset(&wsRcv, 0, sizeof(wsRcv));
	memset(sRcv  , 0, sizeof(sRcv ));

	memset(&olSnd, 0, sizeof(olSnd));
	memset(&wsSnd, 0, sizeof(wsSnd));
	memset(sSnd  , 0, sizeof(sSnd ));

	wsRcv.buf=(char*)sRcv;
	wsRcv.len=sizeof(sRcv);

	wsSnd.buf=(char*)sSnd;
	wsSnd.len=sizeof(sSnd);
	
	olRcv.nEvt = NETEVT_RECV;
	olSnd.nEvt = NETEVT_SEND;
}




INT CLnNetIocp::LnNetIocpHost::AsyncRecv()
{
	INT		hr = -1;
	DWORD	dRcv;		// ���� ����Ʈ ��
	DWORD	dFlg=0;

//	memset(&olRcv, 0, sizeof olRcv);
//	wsRcv.len = sizeof sRcv;
	
	hr = WSARecv(scH, &wsRcv, 1, &dRcv,	&dFlg, &olRcv, NULL);
	
	if(FAILED(LnNet_SocketErrorCheck(hr)))
		return -1;
	
	return 1;
}


INT CLnNetIocp::LnNetIocpHost::AsyncSend()
{
	INT		hr = -1;
	DWORD	dSnd;		// ��� ���� ����Ʈ ��
	DWORD	dFlg=0;		//

	WORD	iSize = 0;

	if(FAILED(rbSnd.PopFront(this->sSnd, &iSize)))
		return 1;

	wsSnd.len = iSize;
	hr = WSASend(scH, &wsSnd, 1, &dSnd,	dFlg, &olSnd, NULL);
	
	if(FAILED(LnNet_SocketErrorCheck(hr)))
		return -1;

	return 1;
}


void CLnNetIocp::LnNetIocpHost::RingBufPush(INT iRcv)
{
//	printf("Recv:%s\n", sRcv+2);

	// �Ϸ�(����)�� ���۳����� �����ۿ� ����.

//	(BYTE*)wsRcv.buf�� �ּҴ�  sRcv�̹Ƿ� 
//	rbRcv.PushBack((BYTE*)wsRcv.buf, iRcv);���
	
	rbRcv.PushBack(sRcv, iRcv);
}


	
	
	
CLnNetIocp::CLnNetIocp()
{
	m_hIocp		= NULL;
	m_hThWrk	= NULL;
	m_dThWrk	= NULL;

	m_pScktMsg	= NULL;
	m_pScktNew	= NULL;
	m_pScktCls	= NULL;
}


CLnNetIocp::~CLnNetIocp()
{
}


INT CLnNetIocp::Create(void* p1, void* p2, void* p3, void* p4)
{
	char* sIp  = (char*)p1;
	char* sPort= (char*)p2;
	char* sPtcl= (char*)p3;
	char* sSvr = (char*)p4;

	memset(m_sIp, 0, sizeof m_sIp);
	memset(m_sPt, 0, sizeof m_sPt);

	if(sIp  )	strcpy(m_sIp, sIp  );
	if(sPort)	strcpy(m_sPt, sPort);
	
	
	if(0==_stricmp("TCP", sPtcl))
		m_PtcType	= NETPRT_TCP;												// Protocol type
	
	else if(0==_stricmp("UDP", sPtcl))
		m_PtcType	= NETPRT_UDP;												// Protocol type
	
	
	if(0==_stricmp("Client", sSvr))
	{
		m_HstType	= NETHST_CLIENT;											// Client
		return Connect(NULL, NULL);
	}
	else if(0==_stricmp("Server", sSvr))
	{
		m_HstType	= NETHST_SERVER;											// Server
		return Listen();
	}
	
	return -1;
}

void CLnNetIocp::Destroy()
{
	printf("CLnNetIocp Destroy\n");
	
	INT iSizeH = m_vIoH.size();

	for(INT it=0; it<iSizeH; ++it)
		delete m_vIoH[it];
	
	m_vIoH.clear();


	if(m_pScktMsg)
	{
		delete m_pScktMsg;
		m_pScktMsg = NULL;
	}

	if(m_pScktNew)
	{
		delete m_pScktNew;
		m_pScktNew = NULL;
	}

	if(m_pScktCls)
	{
		delete m_pScktCls;
		m_pScktCls = NULL;
	}

	Close();

	CloseHandle(m_hIocp);
	
	// ������ �����Ѵ�.
	LnNet_WSACleanup();
}




INT CLnNetIocp::FrameMove()
{
	if( FAILED(m_nThRecv) || FAILED(m_nThSend))
		return -1;

	SendAllData();
	
	return 0;
}



INT CLnNetIocp::Query(char* sCmd, void* pData)
{
//	printf("CLnNetIocp Query:%s\n", sCmd);
	
	if(0==_stricmp("Get Client Number", sCmd))
	{
		*((INT*)pData) = m_vIoH.size();
		return 0;
	}

	else if(0==_stricmp("Receive Socket Count", sCmd))
	{
		*((INT*)pData) = SocketRecvCount();
		return 0;
	}

	else if(0==_stricmp("New Socket Count", sCmd))
	{
		*((INT*)pData) = SocketNewCount();
		return 0;
	}

	else if(0==_stricmp("Close Socket Count", sCmd))
	{
		*((INT*)pData) = SocketCloseCount();
		return 0;
	}

	else if(0==_stricmp("Get Receive Socket", sCmd))
	{
		SOCKET scH=0;
		SocketRecvPop(&scH);
		*((SOCKET*)pData) = scH;

		return 0;
	}

	else if(0==_stricmp("Get New Socket", sCmd))
	{
		SOCKET scH=0;
		SocketNewPop(&scH);
		*((SOCKET*)pData) = scH;

		return 0;
	}

	else if(0==_stricmp("Get Close Socket", sCmd))
	{
		SOCKET scH=0;
		SocketClosePop(&scH);
		*((SOCKET*)pData) = scH;

		return 0;
	}
	
	return -1;
}


INT CLnNetIocp::Close()
{
	// ������ �ݴ´�.
	LnNet_SocketClose(&m_scH);
	m_pIoH.scH = 0;

	// �����带 �����Ѵ�.
	LnNet_ThreadClose(&m_hThRecv);
	LnNet_ThreadClose(&m_hThAccp);

	return 0;
}


INT CLnNetIocp::Connect(char* sIp, char* sPort)
{
	if(sIp  ){	memset(m_sIp, 0, sizeof m_sIp);	strcpy(m_sIp, sIp  );	}
	if(sPort){	memset(m_sPt, 0, sizeof m_sPt);	strcpy(m_sPt, sPort);	}
	
	//2. ���� ��巹�� ����
	LnNet_SocketAddr(&m_sdH, m_sIp, m_sPt);
	
	
	//3. ������ �����.
	if(NETPRT_TCP==m_PtcType)
	{
		if(FAILED(LnNet_SocketTcpCreate(&m_scH, TRUE)))							// TCP������ �����.
			return -1;
		
	}
	else if(NETPRT_UDP==m_PtcType)
	{
		if(FAILED(LnNet_SocketUdpCreate(&m_scH)))								// UDP������ �����.
			return -1;
	}
	

	//4. Ŀ�ؼ��� �õ��Ѵ�.
	if(SUCCEEDED(LnNet_SocketConnect(m_scH, &m_sdH)))
	{
		m_nThConn = TRUE;
		
		// CPU�� ���ڸ� ���ϰ�, Completion Port(IOCP)����.
		INT iNcpu= LnNet_GetSystemProcessNumber();
		m_hIocp  = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);

		if(!m_hIocp)
			return -1;

		// Non blocking, Nagle ����.
		LnNet_SocketNonBlocking(m_scH);
		LnNet_SocketNaggleOff(m_scH);

		iNcpu *= 2;
		m_hThWrk = new HANDLE[iNcpu];											// Thread Handle
		m_dThWrk = new DWORD [iNcpu];											// Thread Handle

		// ����� �ϷḦ ��� ������: CPU ���� * 2
		for(INT i=0; i<iNcpu; ++i)
			m_hThWrk[i] = LnNet_ThreadCreate(ThreadRecv, this, 0, &m_dThWrk[i]);

		//IOCPŬ���̾�Ʈ�� ������ �����Ѵ�.
		m_pIoH.scH = m_scH;
		memset(&m_pIoH.sdH  , 0, sizeof m_sdH  );

		LnNet_IocpPortCreate(m_pIoH.scH, m_hIocp, &m_pIoH);
		m_pIoH.AsyncRecv();
		
		return 1;
	}
	
	return -1;
}



INT CLnNetIocp::Listen()
{
	//2. CPU�� ���ڸ� ���ϰ�, Completion Port(IOCP)����.
	INT iNcpu= LnNet_GetSystemProcessNumber();
	m_hIocp  = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);

	m_pScktMsg = new TqueCrc<CLnNetIocp::TsckMsg >(65536);
	m_pScktNew = new TqueCrc<CLnNetIocp::TsckMsg >(65536);
	m_pScktCls = new TqueCrc<CLnNetIocp::TsckMsg >(65536);

	if(!m_hIocp)
		return -1;

	//3. Overlapped ���� ���� ����
	if(FAILED(LnNet_SocketTcpCreate(&m_scH, TRUE)))
		return -1;


	//4. ���� ��巹�� ����, ���ϻ���
	LnNet_SocketAddr(&m_sdH, m_sIp, m_sPt);

	if(NETPRT_TCP==m_PtcType)
	{
		if(FAILED(LnNet_SocketTcpCreate(&m_scH)))								// TCP������ �����.
			return -1;
		
	}
	else if(NETPRT_UDP==m_PtcType)
	{
		if(FAILED(LnNet_SocketUdpCreate(&m_scH)))								// UDP������ �����.
			return -1;
	}
	
	
	//5. ���� ���ε�
	if(FAILED(LnNet_SocketBind(m_scH, &m_sdH)))
		return -1;
	
	//6. Completion Port ���� ����� �ϷḦ ��� �ϴ� �����带 CPU ���� * 2 ��ŭ ����.
	iNcpu *= 2;
	m_hThWrk = new HANDLE[iNcpu];												// Thread Handle
	m_dThWrk = new DWORD [iNcpu];												// Thread Handle
	
	// Accept�� �����带 �����.
	m_hThAccp = LnNet_ThreadCreate(ThreadAccp, this, 0, &m_dThAccp);


	// Receive, Send�� ������� IOCP������ �ϳ����� �� ó�� �Ѵ�.(RECV���� ó������.)
	for(INT i=0; i<iNcpu; ++i)
		m_hThWrk[i] = LnNet_ThreadCreate(ThreadRecv, this, 0, &m_dThWrk[i]);

	
	//6. ���� ����
	if(FAILED(LnNet_SocketListen(m_scH)))
		return -1;
	
	return 0;
}




INT CLnNetIocp::Send(char* pSrc, INT* iSnd, SOCKET* scH)
{
	if(NULL==scH)
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize = 0;
		INT		iLen = *iSnd;

		iSize = iLen + PCK_BUF_HEAD;

		memcpy(sBuf+PCK_BUF_HEAD, pSrc, iLen);
		*((WORD*)(sBuf+0)) = iSize;

		if(FAILED(m_pIoH.rbSnd.PushBack(sBuf, iSize)))
			return -1;
	}

	else
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize = 0;
		INT		iLen = *iSnd;
		INT		nIdx = -1;

		INT		iN = m_vIoH.size();

		for(nIdx=0; nIdx<iN; ++nIdx)
		{
			if(m_vIoH[nIdx]->scH == *scH)
				break;
		}

		if(nIdx>=iN)
			return -1;

		
		iSize = iLen + PCK_BUF_HEAD;
		
		memcpy(sBuf+PCK_BUF_HEAD, pSrc, iLen);
		*((WORD*)(sBuf+0)) = iSize;
		
		if(FAILED(m_vIoH[nIdx]->rbSnd.PushBack(sBuf, iSize)))
			return -1;
	}
	
	return 0;
}

INT CLnNetIocp::Recv(char* pDst, INT* iRcv, SOCKET* scH)
{
	if(NULL==scH)
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize = 0;

		*iRcv = 0;

		if(FAILED(m_pIoH.rbRcv.PopFront(sBuf, &iSize)))
			return -1;

		if(0==iSize)
			return -1;

		iSize = iSize - PCK_BUF_HEAD;
		memcpy(pDst, sBuf+ PCK_BUF_HEAD, iSize);
		*iRcv = iSize;
	}

	else
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize= 0;
		SOCKET	scT	 =*scH;	
		INT		nIdx = -1;
		INT		iN = m_vIoH.size();
		
		*iRcv = 0;

		LnNetIocpHost** pHst = LnNet_Find_Socket(m_vIoH.begin(), m_vIoH.end(), scT);

		if(NULL == pHst || NULL == *pHst || pHst == m_vIoH.end())
		{
			return -1;
		}

		INT hr = (*pHst)->rbRcv.PopFront(sBuf, &iSize);

		if(FAILED( hr ))
			return -1;
		
		if(0==iSize)
			return -1;
		
		iSize = iSize - PCK_BUF_HEAD;
		memcpy(pDst, sBuf+ PCK_BUF_HEAD, iSize);
		*iRcv = iSize;
	}

	return 0;
}






INT CLnNetIocp::SendAllData()
{
	// ������ ����
	if(NETHST_CLIENT == m_HstType)
	{
		m_pIoH.AsyncSend();
	}
	else if(NETHST_SERVER == m_HstType)
	{
		INT iSizeH = m_vIoH.size();

		for(INT i=0;i<iSizeH; ++i)
		{
			CLnNetIocp::LnNetIocpHost* pIoH = m_vIoH[i];

			pIoH->AsyncSend();
		}
	}

	return 0;
}



DWORD CLnNetIocp::ProcRecv(void* pParam)
{
	while(1)
	{
		LnNetIocpHost*	pIoH;			// �Ϸ� ���� �ּ�
		TlnOVERLAP*		pOL;			// Overlapped�ּ� Send: olSnd, Recv: olRcv
		DWORD			dRcv;			// ���� ũ��
		BOOL			hr=-1;

		hr = GetQueuedCompletionStatus(
				m_hIocp					// Completion Port
			,	&dRcv					// �Ϸ�(ó��) ����Ʈ ��
			,	(LPDWORD)&pIoH			// pIoH �ּ�
			,	(LPOVERLAPPED*)&pOL		// pIoH�� olSnd or olRcv �ּ�
			,	INFINITE
			);

			
		//EOF ���۽�. Ŭ���̾�Ʈ ���� ����
		if(0 == dRcv)
		{
			if(NETHST_CLIENT == m_HstType)
			{
				m_nThConn = 0;
				m_nThRecv = -1;
				return -1;
			}

			else if(NETHST_SERVER == m_HstType)
			{
				SOCKET scT = pIoH->scH;
				
				//������ ����				
				pIoH->Destroy();

				// ����Ʈ���� �����Ѵ�.
				INT		iSizeH = m_vIoH.size();
				itIocpH itIoH = 0;

				for(INT i=0; i<iSizeH; ++i)
				{
					if(pIoH == m_vIoH[i])
					{
						itIoH = m_vIoH.begin() + i;
						break;
					}
				}
				
				delete pIoH;
				m_vIoH.erase(itIoH);

				printf("Close: %d, Remain: %d\n", scT, m_vIoH.size());

				// ������ ���ϸ���Ʈ�� ���
				SocketClosePush(scT);
			}

			continue;
		}

		// Receive Complete
		if(NETEVT_RECV == pOL->nEvt)
		{
			if(NETHST_CLIENT == m_HstType)
			{
				pIoH->RingBufPush(dRcv);
				pIoH->AsyncRecv();
			}
			else if(NETHST_SERVER == m_HstType)
			{
				// 12. ���� �����͸� �����ۿ� ����.
				pIoH->RingBufPush(dRcv);

				SocketRecvPush(pIoH->scH);

				// 13. �ٽ� �񵿱� ������ �Է� ��û.(�ʼ�)
				pIoH->AsyncRecv();
			}
		}

		// Send complete
		else if(NETEVT_SEND == pOL->nEvt)
		{
			printf("Send complete: %d\n", pIoH->scH);
		}
	}


	m_nThRecv = 0;
	return 0;
}





DWORD CLnNetIocp::ProcAccp(void* pParam)
{
	printf("CLnNetIocp:ProcAccept\n");

	INT		hr=-1;
	INT		i=0;

	while(1)
	{
		// Accept
		SOCKET			scH;
		SOCKADDR_IN		sdH;
		hr = LnNet_SocketAccept(&scH, &sdH, m_scH);

		if(FAILED(hr))
		{
			m_nThAccp = -1;
			return -1;
		}

		if(hr)
		{
			printf("New Client socket:%d\n", scH);

			LnNetIocpHost* pIoH = new LnNetIocpHost(scH, &sdH);
			m_vIoH.push_back(pIoH);

			LnNet_IocpPortCreate(pIoH->scH, m_hIocp, pIoH);
			pIoH->AsyncRecv();


			// ���� ���ϸ���Ʈ�� ���
			SocketNewPush(scH);
		}
	}

	m_nThAccp = 0;
	return 0;
}



void CLnNetIocp::SocketRecvPush(SOCKET scH)
{
	CLnNetIocp::TsckMsg msg(scH);
	m_pScktMsg->PushBack(&msg);
}

INT CLnNetIocp::SocketRecvPop(SOCKET* scH)
{
	if(m_pScktMsg->IsEmpty())
		return -1;

	CLnNetIocp::TsckMsg msg;

	// �޽��� ���ۿ��� ������ �����´�.
	m_pScktMsg->PopFront(&msg);
	*scH = msg.nScH;

	return m_pScktMsg->GetSize();
}

INT CLnNetIocp::SocketRecvCount()
{
	return m_pScktMsg->GetSize();
}



void CLnNetIocp::SocketNewPush(SOCKET scH)
{
	CLnNetIocp::TsckMsg msg(scH);
	m_pScktMsg->PushBack(&msg);
}

INT CLnNetIocp::SocketNewPop(SOCKET* scH)
{
	if(m_pScktMsg->IsEmpty())
		return -1;

	CLnNetIocp::TsckMsg msg;

	// �޽��� ���ۿ��� ������ �����´�.
	m_pScktMsg->PopFront(&msg);
	*scH = msg.nScH;

	return m_pScktMsg->GetSize();
}

INT CLnNetIocp::SocketNewCount()
{
	return m_pScktMsg->GetSize();
}



void CLnNetIocp::SocketClosePush(SOCKET scH)
{
	CLnNetIocp::TsckMsg msg(scH);
	m_pScktMsg->PushBack(&msg);
}

INT CLnNetIocp::SocketClosePop(SOCKET* scH)
{
	if(m_pScktMsg->IsEmpty())
		return -1;

	CLnNetIocp::TsckMsg msg;

	// �޽��� ���ۿ��� ������ �����´�.
	m_pScktMsg->PopFront(&msg);
	*scH = msg.nScH;

	return m_pScktMsg->GetSize();
}

INT CLnNetIocp::SocketCloseCount()
{
	return m_pScktMsg->GetSize();
}

