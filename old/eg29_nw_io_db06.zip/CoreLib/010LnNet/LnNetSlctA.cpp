// Implementation of the CLnNetSlctA class.
//
////////////////////////////////////////////////////////////////////////////////

#include <WINSOCK2.H>
#include <windows.h>
#include <stdio.h>

#include "LnNetUtil.h"
#include "ILnNet.h"

#include "LnNetUtil.h"
#include "LnNetBase.h"
#include "LnNetSlctA.h"



CLnNetSlctA::LnNetSlctHost::LnNetSlctHost()
{
	scH = 0;
	memset(&sdH, 0, sizeof(sdH));
}


CLnNetSlctA::CLnNetSlctA()
{
	m_iNsck	= 0;

	m_hWnd	= 0;
	m_dwMsg	= 0;
}


CLnNetSlctA::~CLnNetSlctA()
{
	CLnNetSlctA::Destroy();
}


INT CLnNetSlctA::Create(void* p1, void* p2, void* p3, void* p4)
{
	char* sIp  = (char*)p1;
	char* sPort= (char*)p2;
	char* sPtcl= (char*)p3;
	char* sSvr = (char*)p4;
	
	memset(m_sIp, 0, sizeof m_sIp);
	memset(m_sPt, 0, sizeof m_sPt);
	
	if(sIp  )	strcpy(m_sIp, sIp  );
	if(sPort)	strcpy(m_sPt, sPort);
	
	
	if(0==_stricmp("TCP", sPtcl))
		m_PtcType	= NETPRT_TCP;												// Protocol type
	
	else if(0==_stricmp("UDP", sPtcl))
		m_PtcType	= NETPRT_UDP;												// Protocol type
	
	
	if(0==_stricmp("Client", sSvr))
	{
		m_HstType	= NETHST_CLIENT;											// Client
		return Connect(NULL, NULL);
	}
	else if(0==_stricmp("Server", sSvr))
	{
		m_HstType	= NETHST_SERVER;											// Server
		return Listen();
	}
	
	return -1;
}

void CLnNetSlctA::Destroy()
{
	Close();
	
	// ������ �����Ѵ�.
	LnNet_WSACleanup();
}




INT CLnNetSlctA::FrameMove()
{
	if( FAILED(m_nThRecv) || FAILED(m_nThSend))
		return -1;

	SendAllData();

	return 0;
}



INT CLnNetSlctA::Query(char* sCmd, void* pData)
{
	if(0==_stricmp("Get Client Number", sCmd))
	{
		*((INT*)pData) = m_iNsck-1;
		return 0;
	}

	else if(0==_stricmp("Set Window Handle", sCmd))
	{
		m_hWnd = *((HWND*)pData);
		return 0;
	}

	else if(0==_stricmp("Set Message Value", sCmd))
	{
		m_dwMsg = *((DWORD*)pData);
		return 0;
	}

	else if(0==_stricmp("Window Procedure", sCmd))
	{
		char* sData = (char*)pData;

		HWND	hWnd = *((HWND*  )(sData + 0));
		UINT	uMsg = *((UINT*  )(sData + 4));
		WPARAM	wPar = *((WPARAM*)(sData + 8));
		LPARAM  lPar = *((LPARAM*)(sData +12));

		return MsgProc(hWnd, uMsg, wPar, lPar);
	}

	
	
	return -1;
}




INT CLnNetSlctA::Connect(char* sIp, char* sPort)
{
	if(sIp  ){	memset(m_sIp, 0, sizeof m_sIp);	strcpy(m_sIp, sIp  );	}
	if(sPort){	memset(m_sPt, 0, sizeof m_sPt);	strcpy(m_sPt, sPort);	}
	
	//2. ���� ��巹�� ����
	LnNet_SocketAddr(&m_sdH, m_sIp, m_sPt);
	
	
	//3. ������ �����.
	if(NETPRT_TCP==m_PtcType)
	{
		if(FAILED(LnNet_SocketTcpCreate(&m_scH)))								// TCP������ �����.
			return -1;
		
	}
	else if(NETPRT_UDP==m_PtcType)
	{
		if(FAILED(LnNet_SocketUdpCreate(&m_scH)))								// UDP������ �����.
			return -1;
	}
	

	//�񵿱� ����. 
	INT hr = WSAAsyncSelect(m_scH, m_hWnd, m_dwMsg, FD_CONNECT|FD_READ|FD_WRITE|FD_CLOSE);

	//4. Ŀ�ؼ�
	hr = LnNet_SocketConnect(m_scH, &m_sdH);

	if(FAILED(LnNet_SocketErrorCheck(hr)))
		return -1;
	
	m_nThConn = TRUE;
		
	// Nagle ����.
	LnNet_SocketNaggleOff(m_scH);

	Ev_Zero();
	Ev_Set(m_scH, &m_sdH);

	return 1;	
}




INT CLnNetSlctA::Close()
{
	// ������ �ݴ´�.
	LnNet_SocketClose(&m_scH);
	
	m_rbSnd.Clear();
	m_rbRcv.Clear();
	
	return 0;
}

INT CLnNetSlctA::Listen()
{
	//2. ���� ��巹�� ����
	LnNet_SocketAddr(&m_sdH, m_sIp, m_sPt);
	
	
	//3. ������ �����.
	if(NETPRT_TCP==m_PtcType)
	{
		if(FAILED(LnNet_SocketTcpCreate(&m_scH)))								// TCP������ �����.
			return -1;
		
	}
	else if(NETPRT_UDP==m_PtcType)
	{
		if(FAILED(LnNet_SocketUdpCreate(&m_scH)))								// UDP������ �����.
			return -1;
	}
	
	
	//3. ���� ���ε�
	if(FAILED(LnNet_SocketBind(m_scH, &m_sdH)))
		return -1;
	
	// �񵿱� ����
	// The WSAAsyncSelect function automatically sets socket s to nonblocking mode
	INT hr = WSAAsyncSelect(m_scH, m_hWnd, m_dwMsg, FD_ACCEPT|FD_READ|FD_WRITE|FD_CLOSE);

	if(FAILED(LnNet_SocketErrorCheck(hr)))
		return -1;

	if(FAILED(LnNet_SocketListen(m_scH)))
		return -1;

	Ev_Zero();
	Ev_Set(m_scH, &m_sdH);

	return 0;
}




INT CLnNetSlctA::Send(char* pSrc, INT* iSnd, SOCKET* scH)
{
	if(NULL==scH)
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize = 0;
		INT		iLen = *iSnd;

		iSize = iLen + PCK_BUF_HEAD;

		memcpy(sBuf+PCK_BUF_HEAD, pSrc, iLen);
		*((WORD*)(sBuf+0)) = iSize;

		if(FAILED(m_rbSnd.PushBack(sBuf, iSize)))
			return -1;
	}

	else
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize= 0;
		INT		iLen = *iSnd;
		INT		nIdx = 1;

		for(nIdx=1; nIdx<m_iNsck; ++nIdx)
		{
			if(m_rmH[nIdx].scH == *scH)
				break;
		}

		if(nIdx>=m_iNsck)
			return -1;

		
		iSize = iLen + PCK_BUF_HEAD;
		
		memcpy(sBuf+PCK_BUF_HEAD, pSrc, iLen);
		*((WORD*)(sBuf+0)) = iSize;
		
		if(FAILED(m_rmH[nIdx].rbSnd.PushBack(sBuf, iSize)))
			return -1;
	}
	
	return 0;
}

INT CLnNetSlctA::Recv(char* pDst, INT* iRcv, SOCKET* scH)
{
	if(NULL==scH)
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize = 0;

		*iRcv = 0;

		if(FAILED(m_rbRcv.PopFront(sBuf, &iSize)))
			return -1;

		if(0==iSize)
			return -1;

		iSize = iSize - PCK_BUF_HEAD;
		memcpy(pDst, sBuf+ PCK_BUF_HEAD, iSize);
		*iRcv = iSize;
	}

	else
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		WORD	iSize = 0;
		INT		nIdx = *scH+1;
		
		*iRcv = 0;

		if(nIdx> m_iNsck || nIdx<0)
			return -1;

		if(FAILED(m_rmH[nIdx].rbRcv.PopFront(sBuf, &iSize)))
			return -1;
		
		if(0==iSize)
			return -1;
		
		iSize = iSize - PCK_BUF_HEAD;
		memcpy(pDst, sBuf+ PCK_BUF_HEAD, iSize);
		*iRcv = iSize;

		*scH = m_rmH[nIdx].scH;
	}

	return 0;
}




LRESULT CLnNetSlctA::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(msg != m_dwMsg)
		return 0;
	
	DWORD	dErr;
	DWORD	dMsg;

	dErr = WSAGETSELECTERROR(lParam);
	dMsg = WSAGETSELECTEVENT(lParam);

	if(  0            == dErr && 
		!(FD_ACCEPT   == dMsg ||
		  FD_CONNECT  == dMsg ||
		  FD_READ     == dMsg ||
		  FD_WRITE    == dMsg ||
		  FD_CLOSE    == dMsg ||
		  FD_OOB      == dMsg ||
		  FD_QOS      == dMsg ||
		  FD_GROUP_QOS== dMsg    ) )
		  return 0;

	SOCKET	scH = (SOCKET)wParam;

	if(dErr)
	{
		printf("Network Error\n");

		if(NETHST_CLIENT == m_HstType || m_scH == scH)
		{
			m_nThRecv = -1;
			return -1;
		}
		else
		{
			SOCKET sT =scH;
			LnNet_SocketClose(&sT);
			Ev_Clr(scH);
			printf("Close socket: %d Remain: %d\n", scH, (m_iNsck-1));
		}

		return 0;
	}


	if(FD_ACCEPT == dMsg)						// Accept
	{
		SOCKET		scCln;
		SOCKADDR_IN	sdCln;

		if(SUCCEEDED(LnNet_SocketAccept(&scCln, &sdCln, m_scH)))
		{
			if(scCln)
			{
				// �񵿱� ����Ʈ�� �����Ѵ�.
				WSAAsyncSelect(scCln, hWnd, m_dwMsg, (FD_READ|FD_WRITE|FD_CLOSE));

				Ev_Set(scCln, &sdCln);	// ����...
				printf("New Client: %d \n", scCln);
			}
		}

		return 0;
	}

	else if(FD_CONNECT == dMsg)
	{
		m_nThConn = TRUE;
		return 0;
	}

	else if(FD_READ == dMsg)					// Receive
	{
		BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
		INT		iSize = 0;

		if(NETHST_CLIENT == m_HstType && scH == m_scH)
		{	
			iSize=recv(m_scH, (char*)sBuf, sizeof sBuf, 0);

			if(iSize>0)
			{
				printf("%s\n", sBuf+2);

				sBuf[iSize]=0;
				m_rbRcv.PushBack(sBuf, iSize);
			}
		}
		
		else if(NETHST_SERVER == m_HstType)
		{
			for(INT i=1; i<m_iNsck; ++i)
			{
				SOCKET		s = m_rmH[i].scH;

				if(s == scH)
				{
					iSize=recv(s, (char*)sBuf, sizeof sBuf, 0);

					if(iSize>0)
					{
						printf("%s\n", sBuf+2);

						sBuf[iSize]=0;
						m_rmH[i].rbRcv.PushBack(sBuf, iSize);
					}
				}
			}
		}

		return 0;
	}

	else if(FD_CLOSE == dMsg)
	{
		if(NETHST_CLIENT == m_HstType)
		{
			m_nThRecv = -1;
			return -1;
		}
		else if(NETHST_SERVER == m_HstType)
		{
			SOCKET sT =scH;
			LnNet_SocketClose(&sT);
			Ev_Clr(scH);

			printf("Close socket: %d Remain: %d\n", scH, (m_iNsck-1));
		}

		return 0;
	}
	
	return 0;
}



INT CLnNetSlctA::SendAllData()
{
	INT		hr=-1;
	
	// ������ �����ۿ� �ִ� ������ �����ͼ� ��Ŷ�� ������.
	BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
	WORD	iSize = 0;
	
	// ������ ����
	if(NETHST_CLIENT == m_HstType)
	{
		if(FAILED(m_rbSnd.PopFront(sBuf, &iSize)))
			return 0;
		
		hr = send(m_scH, (char*)sBuf, iSize, 0);
	}
	
	else if(NETHST_SERVER == m_HstType)
	{
		for(INT j=1;j<m_iNsck; ++j)
		{
			if(m_scH != m_rmH[j].scH)
			{
				if(SUCCEEDED(m_rmH[j].rbSnd.PopFront(sBuf, &iSize)))
				{
					hr = send(m_rmH[j].scH, (char*)sBuf, iSize, 0);
				}
			}
		}
	}

	return 0;
}






void CLnNetSlctA::Ev_Set(SOCKET scH, SOCKADDR_IN* sdH)
{
	INT i;
	
	for (i=0; i<m_iNsck; ++i)
	{
		if (m_rmH[i].scH == scH)
		{
			break;
		}
	}

	if (i == m_iNsck)
	{
		if (m_iNsck < WSA_MAXIMUM_WAIT_EVENTS)
		{
			m_rmH[i].scH = scH;

			m_iNsck++;
		}
	}
}


void CLnNetSlctA::Ev_Clr(SOCKET scH)
{
	INT i;

	for (i=0; i<m_iNsck; ++i)
	{
		if (m_rmH[i].scH == scH)
		{
			while (i < m_iNsck-1)
			{
				memcpy(&m_rmH[i], &m_rmH[i+1], sizeof(CLnNetSlctA::LnNetSlctHost));
				
				++i;
			}
			
			INT nCnt = m_iNsck-1;

			m_rmH[nCnt].rbRcv.Clear();
			m_rmH[nCnt].rbSnd.Clear();

			m_iNsck--;
			break;
		}
	}
}


void CLnNetSlctA::Ev_Zero()
{
	m_iNsck =0;
}