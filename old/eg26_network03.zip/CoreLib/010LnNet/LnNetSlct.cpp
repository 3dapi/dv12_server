// Implementation of the CLnNetSlct class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"
#include "LnNetSlct.h"



CLnNetSlct::CLnNetSlct()
{
}


CLnNetSlct::~CLnNetSlct()
{
}

INT CLnNetSlct::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetSlct Create\n");

	return 0;
}

void CLnNetSlct::Destroy()
{
	printf("CLnNetSlct Destroy\n");
}


INT CLnNetSlct::Query(char* sCmd, void* pData)
{
	printf("CLnNetSlct Query:%s\n", sCmd);

	if(0==_stricmp("Query", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}


