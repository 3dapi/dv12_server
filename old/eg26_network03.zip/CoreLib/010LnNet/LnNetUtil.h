// Interface for the LnNetUtil functions.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetUtil_H_
#define _LnNetUtil_H_


void	LnNet_FormatMessage(char* sMsg);		// Network Message Formating
void	LnNet_GetNetworkError(DWORD hr);		// Network Error Message Catching
INT		LnNet_WSAGetError();

INT		LnNet_WSAStartup();						// ���� ���̺귯�� �ʱ�ȭ
void	LnNet_WSACleanup();						// ���� ���̺귯�� ����


void	LnNet_SocketAddr(SOCKADDR_IN* pOut, char* sIp, char* sPort);			// Setting Socket Address

void	LnNet_SocketClose(SOCKET* scH);											// Socket Close

INT		LnNet_SocketTcpCreate(SOCKET* pScH, BOOL bOverLapped=FALSE);			// Create TCP Socket
INT		LnNet_SocketUdpCreate(SOCKET* pScH, BOOL bOverLapped=FALSE);			// Create UDP Socket

INT		LnNet_SocketConnect(SOCKET scH, SOCKADDR_IN* psdH);						// Connection

INT		LnNet_SocketBind(SOCKET scH, SOCKADDR_IN* pSdH);						// Socket Binding
INT		LnNet_SocketListen(SOCKET scH);											// Socket Listen
INT		LnNet_SocketAccept(SOCKET* pscOut			// Output Socket
							, SOCKADDR_IN* psdOut	// Output Socket Address
							, SOCKET scListen		// Listen socket
							);						// Accept





typedef unsigned (__stdcall* _PBEGIN_THREAD_EX)(void*);							// Thread�� �Լ�������
typedef _PBEGIN_THREAD_EX LPBEGIN_THREAD_EX;									//

HANDLE	LnNet_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,void* pParam, ULONG dFlag=0, DWORD* dId= NULL);	// Thread Create
void	LnNet_ThreadClose(HANDLE* hThread);																// Thread Close
DWORD	LnNet_ThreadResume(HANDLE* hThread);									// Thread resume
DWORD	LnNet_ThreadSuspend(HANDLE* hThread);									// Thread Suspend



#endif


