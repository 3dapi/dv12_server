// Implementation of the CLnDbBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <stdio.h>

#include "ILnDataBase.h"
#include "LnDbBase.h"



CLnDbBase::CLnDbBase()
{
	m_eType		= DB_NONE;			// DataBase Type

	memset(	m_sHst, 0, sizeof m_sHst);
	memset(	m_sDsn, 0, sizeof m_sDsn);
	memset(	m_sUid, 0, sizeof m_sUid);
	memset(	m_sPwd, 0, sizeof m_sPwd);
}


CLnDbBase::~CLnDbBase()
{

}


INT CLnDbBase::Create(void* p1, void* p2, void* p3, void* p4)
{
	return -1;
}


void CLnDbBase::Destroy()
{
}


INT CLnDbBase::Query(char* sCmd, void* pData)
{
	return -1;
}



void CLnDbBase::Close()
{
}



INT CLnDbBase::Connect(void* pDataType, void* p1, void* p2, void* p3)
{
	return -1;
}


INT CLnDbBase::SqlBind(char* sQuery, char*** sDataBufc,INT** nDataBufc, INT nBufSize)
{
	return -1;
}


INT CLnDbBase::SqlExec()
{
	return -1;
}



INT CLnDbBase::SqlClose()
{
	return -1;
}

