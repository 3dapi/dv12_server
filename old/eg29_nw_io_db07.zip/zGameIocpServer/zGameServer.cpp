// Server Application
//
////////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "Winmm.lib")

#include <vector>

#include <windows.h>
#include <Mmsystem.h>
#include <stdio.h>


#include "../include/LnLib/ILnNet.h"


ILnNet*		g_pNet=NULL;				// Network Instance


void main()
{
	printf("\n��Ʈ��ũ �غ�--------------------\n");

	// ������ �ʱ�ȭ
	if(FAILED(LnNet_WinSockCreate()))
		return;


	if(FAILED(LnNet_CreateTcpServer("IOCP", &g_pNet, NULL, "20000")))
		return;

	printf("\n\n��Ʈ��ũ ����--------------------\n");


	char	sBufSnd[1040]={0};
	char	sBufRcv[1040]={0};
	int		iLenSnd=0;
	int		iLenRcv=0;

	while(1)
	{
		Sleep(1);

		INT nCnt =0;

//		if(SUCCEEDED(g_pNet->Query("Get Client Number", &nCnt)))
//		{
//			for(int i=0; i<nCnt; ++i)
//			{
//				SOCKET scH = i;
//				
//				memset(sBufRcv, 0, sizeof sBufRcv);
//				g_pNet->Recv(sBufRcv, &iLenRcv, &scH);
//
//				if(iLenRcv>0)
//				{
//					printf("Recv:%s\n", sBufRcv);
//					sprintf(sBufSnd, "Echo:%s", sBufRcv);
//					iLenSnd=strlen(sBufSnd);
//
//					g_pNet->Send(sBufSnd, &iLenSnd, &scH);
//				}
//			}
//		}

		INT nNewCount=0;
		if(SUCCEEDED(g_pNet->Query("New Socket Count", &nNewCount)))
		{
 			while(nNewCount>0)
			{
				SOCKET scNew=0;

				if(SUCCEEDED(g_pNet->Query("Get New Socket", &scNew)))
				{
					int		iLenSnd=0;
					char	sBufSnd[1024]={0};
					sprintf(sBufSnd, "SocketId:%d", scNew);
					iLenSnd=strlen(sBufSnd);

					g_pNet->Send(sBufSnd, &iLenSnd, &scNew);
				}

				--nNewCount;
			}
		}

		

		std::vector<SOCKET > plsSocket;

		if(SUCCEEDED(g_pNet->Query("Get Socket List", &plsSocket)))
		{
//			printf("Socket List: ");
//			int iSize =plsSocket.size();
//
//
//			for(int i=0; i<iSize; ++i)
//			{
//				printf("%5d", plsSocket[i]);
//			}
//
//			printf("\n");
		}


		if(SUCCEEDED(g_pNet->Query("Receive Socket Count", &nCnt)))
		{
			for(int i=0; i<nCnt; ++i)
			{
				SOCKET scH = 0;

				if(SUCCEEDED(g_pNet->Query("Get Receive Socket", &scH)))
				{
					memset(sBufRcv, 0, sizeof sBufRcv);
					g_pNet->Recv(sBufRcv, &iLenRcv, &scH);

					if(iLenRcv>0)
					{
						printf("Recv:%s\n", sBufRcv);
						sprintf(sBufSnd, "RecvOk %4d : %s",scH, sBufRcv);
						iLenSnd=strlen(sBufSnd);

						g_pNet->Send(sBufSnd, &iLenSnd, &scH);

						sprintf(sBufSnd, "Echo %4d : %s",scH, sBufRcv);
						iLenSnd=strlen(sBufSnd);

 						int iSocketSize = plsSocket.size();
 
 						for(int i=0; i<iSocketSize; ++i)
 						{
 							SOCKET scT = plsSocket[i];
 
 							if( scH != scT)
 								g_pNet->Send(sBufSnd, &iLenSnd, &scT);
 						}
					}
				}

				
			}
		}


		if(FAILED(g_pNet->FrameMove()))
			break;
	}

	printf("\n��Ʈ��ũ ����--------------------\n\n");
	delete g_pNet;

	// ��������
	LnNet_WinsockDestroy();
}



