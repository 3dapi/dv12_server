// Implementation of the CLnNetBlc class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "LnNetUtil.h"
#include "ILnNet.h"

#include "LnNetUtil.h"
#include "LnNetBase.h"
#include "LnNetBlc.h"



CLnNetBlc::CLnNetBlc()
{
	m_evSnd	= 0;
	m_scCln = 0;
}


CLnNetBlc::~CLnNetBlc()
{
}


INT CLnNetBlc::Create(void* p1, void* p2, void* p3, void* p4)
{
	char* sIp  = (char*)p1;
	char* sPort= (char*)p2;
	char* sPtcl= (char*)p3;
	char* sSvr = (char*)p4;

	//1. ������ �ʱ�ȭ
	if(FAILED(LnNet_WSAStartup()))
		return -1;

	memset(m_sIp, 0, sizeof m_sIp);
	memset(m_sPt, 0, sizeof m_sPt);

	if(sIp  )	strcpy(m_sIp, sIp  );
	if(sPort)	strcpy(m_sPt, sPort);
	
	
	if(0==_stricmp("TCP", sPtcl))
		m_PtcType	= NETPT_TCP;												// Protocol type

	else if(0==_stricmp("UDP", sPtcl))
		m_PtcType	= NETPT_UDP;												// Protocol type


	if(0==_stricmp("Client", sSvr))
	{
		m_HstType	= NETHST_CLIENT;											// Client
		return Connect(NULL, NULL);
	}
	else if(0==_stricmp("Server", sSvr))
	{
		m_HstType	= NETHST_SERVER;											// Server
		return Listen();
	}

	return -1;
}

void CLnNetBlc::Destroy()
{
	printf("CLnNetBlc Destroy\n");

	Close();

	// ������ �����Ѵ�.
	LnNet_WSACleanup();
}



INT CLnNetBlc::Query(char* sCmd, void* pData)
{
	printf("CLnNetBlc Query:%s\n", sCmd);

	if(0==_stricmp("Query", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}




INT CLnNetBlc::FrameMove()
{
	LnNet_EventResume(m_evSnd);

	if( FAILED(m_nThRecv) || FAILED(m_nThSend)  || FAILED(m_nThAccp) )
		return -1;

	return 0;
}






INT CLnNetBlc::Connect(char* sIp, char* sPort)
{
	if(sIp  ){	memset(m_sIp, 0, sizeof m_sIp);	strcpy(m_sIp, sIp  );	}
	if(sPort){	memset(m_sPt, 0, sizeof m_sPt);	strcpy(m_sPt, sPort);	}

	//2. ���� ��巹�� ����
	LnNet_SocketAddr(&m_sdH, m_sIp, m_sPt);


	//3. ������ �����.
	if(NETPT_TCP==m_PtcType)
	{
		if(FAILED(LnNet_SocketTcpCreate(&m_scH)))								// TCP������ �����.
			return -1;

	}
	else if(NETPT_UDP==m_PtcType)
	{
		if(FAILED(LnNet_SocketUdpCreate(&m_scH)))								// UDP������ �����.
			return -1;
	}


	//4. Ŀ�ؼ��� �õ��Ѵ�.
	if(SUCCEEDED(LnNet_SocketConnect(m_scH, &m_sdH)))
	{
		m_bConn = TRUE;

		m_rbSnd.SetSize(PCK_BUF_MAX_QUEUE);
		m_rbRcv.SetSize(PCK_BUF_MAX_QUEUE);

		// connection�� �����ϸ� Receive, Send�� �����带 �����.
		// Receive, Send�� �����带 �����.

		m_evSnd = LnNet_EventCreate();		// Send�� Event

		m_hThRecv = LnNet_ThreadCreate(ThreadRecv, this, 0, &m_dThRecv);
		m_hThSend = LnNet_ThreadCreate(ThreadSend, this, 0, &m_dThSend);

		return 1;
	}

	return -1;
}




INT CLnNetBlc::Close()
{
	// ������ �ݴ´�.
	LnNet_SocketClose(&m_scH);

	// �����带 �����Ѵ�.
	LnNet_ThreadClose(&m_hThRecv);
	LnNet_ThreadClose(&m_hThSend);
	LnNet_ThreadClose(&m_hThAccp);

	// �̺�Ʈ�� �����Ѵ�.
	LnNet_EventSuspend(m_evSnd);
	LnNet_EventClose(&m_evSnd);

	m_rbSnd.Clear();
	m_rbRcv.Clear();

	return 0;
}

INT CLnNetBlc::Listen()
{
	//2. ���� ��巹�� ����
	LnNet_SocketAddr(&m_sdH, m_sIp, m_sPt);


	//3. ������ �����.
	if(NETPT_TCP==m_PtcType)
	{
		if(FAILED(LnNet_SocketTcpCreate(&m_scH)))								// TCP������ �����.
			return -1;

	}
	else if(NETPT_UDP==m_PtcType)
	{
		if(FAILED(LnNet_SocketUdpCreate(&m_scH)))								// UDP������ �����.
			return -1;
	}


	//3. ���� ���ε�
	if(FAILED(LnNet_SocketBind(m_scH, &m_sdH)))
		return -1;

	if(FAILED(LnNet_SocketListen(m_scH)))
		return -1;

	
	// Accept, Receive, Send�� �����带 �����.
	m_evSnd = LnNet_EventCreate();				// Send�� Event

	m_hThAccp = LnNet_ThreadCreate(ThreadAccp, this, 0, &m_dThAccp);
	m_hThRecv = LnNet_ThreadCreate(ThreadRecv, this, CREATE_SUSPENDED, &m_dThRecv);
	m_hThSend = LnNet_ThreadCreate(ThreadSend, this, CREATE_SUSPENDED, &m_dThSend);
	
	return 0;
}


INT CLnNetBlc::Send(char* pSrc, INT* iSnd)
{
	BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
	WORD	iSize = 0;
	INT		iLen = *iSnd;

	iSize = iLen + PCK_BUF_HEAD;

	memcpy(sBuf+PCK_BUF_HEAD, pSrc, iLen);
	*((WORD*)(sBuf+0)) = iSize;

	if(FAILED(m_rbSnd.PushBack(sBuf, iSize)))
		return -1;

	return 0;
}

INT CLnNetBlc::Recv(char* pDst, INT* iRcv)
{
	BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
	WORD	iSize = 0;

	*iRcv = 0;

	if(FAILED(m_rbRcv.PopFront(sBuf, &iSize)))
		return -1;

	if(0==iSize)
		return -1;

	iSize = iSize - PCK_BUF_HEAD;
	memcpy(pDst, sBuf+ PCK_BUF_HEAD, iSize);
	*iRcv = iSize;

	return 0;
}



DWORD CLnNetBlc::ProcRecv(void* pParam)
{
	// ��Ŷ�� �޾Ƽ� �ޱ� �����ۿ� ������ ����.
	BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
	INT		iSize = 0;

	while(1)
	{
		//4. ������ ����

		if(NETHST_CLIENT == m_HstType)
		{
			iSize=recv(m_scH, (char*)sBuf, sizeof sBuf, 0);
		}
		
		else if(NETHST_SERVER == m_HstType && m_scCln)
		{
			iSize=recv(m_scCln, (char*)sBuf, sizeof sBuf, 0);
		}

		if(SOCKET_ERROR == iSize)
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				m_nThRecv = -1;
				return -1;
			}
		}

		if(iSize<=0)
			continue;

		printf("%s\n", sBuf+2);

		sBuf[iSize]=0;
		m_rbRcv.PushBack(sBuf, iSize);
	}

	m_nThRecv = 0;
	return 0;
}



DWORD CLnNetBlc::ProcSend(void* pParam)
{
	// ������ �����ۿ� �ִ� ������ �����ͼ� ��Ŷ�� ������.
	BYTE	sBuf[PCK_BUF_MAX_MSG]={0};
	WORD	iSize = 0;

	while(1)
	{
		//6. ������ ����
		LnNet_EventWait(m_evSnd, INFINITE);

		if(FAILED(m_rbSnd.PopFront(sBuf, &iSize)))
			continue;

		if(NETHST_CLIENT == m_HstType)
		{
			send(m_scH, (char*)sBuf, iSize, 0);
		}

		else if(NETHST_SERVER == m_HstType && m_scCln)
		{
			send(m_scCln, (char*)sBuf, iSize, 0);
		}
	}

	m_nThSend = 0;	
	return 0;
}

DWORD CLnNetBlc::ProcAccp(void* pParam)
{
	printf("CLnNetBlc:ProcAccept\n");

	INT			hr=-1;
	INT			i=0;

	while(1)
	{
		int		iSizeAdd = sizeof(SOCKADDR_IN);


		// Accept
		hr = LnNet_SocketAccept(&m_scCln, &m_sdCln, m_scH);

		if(FAILED(hr))
		{
			m_nThAccp = -1;
			return -1;
		}

		if(hr)
		{
			// ���⼭ Ŭ���̾�Ʈ ���ӿ� ���� �ڷᱸ���� ó��
			LnNet_ThreadResume(&m_hThRecv);
			LnNet_ThreadResume(&m_hThSend);

			printf("New Client socket:%d\n", m_scCln);
		}
	}

	m_nThAccp = 0;
	return 0;
}