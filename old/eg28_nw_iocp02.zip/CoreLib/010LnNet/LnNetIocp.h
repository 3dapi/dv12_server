// Interface for the CLnNetIocp class.
// Network I/O IOCP
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetIocp_H_
#define _LnNetIocp_H_

#pragma warning(disable : 4786)
#include <vector>

class CLnNetIocp : public CLnNetBase
{
public:
	struct Tmsg
	{
		SOCKET		nScH;

		Tmsg():nScH(0)	{}
		Tmsg(SOCKET _scH):nScH(_scH){}
	};

	struct TlnOVERLAP : public OVERLAPPED
	{
		INT		nEvt;		//Send: NETEVT_SEND, Recv: NETEVT_RECV
	};

	struct LnNetIocpHost
	{
		SOCKET		scH;														// ���� Ŭ���̾�Ʈ ����
		SOCKADDR_IN sdH;														// ���� Ŭ���̾�Ʈ ��巹��

		TlnOVERLAP	olRcv;
		WSABUF		wsRcv;
		BYTE		sRcv[PCK_BUF_MAX_MSG];										// wsRcv.buf�� �����

		TlnOVERLAP	olSnd;
		WSABUF		wsSnd;		
		BYTE		sSnd[PCK_BUF_MAX_MSG];										// wsSnd.buf�� �����

		TRingBuf	rbSnd;														// ���� Ŭ���̾�Ʈ Send�� ������
		TRingBuf	rbRcv;														// ���� Ŭ���̾�Ʈ Receive�� ������

		LnNetIocpHost();
		LnNetIocpHost(SOCKET _scH, SOCKADDR_IN* _sdH);

		void	Destroy();
		INT		AsyncRecv();
		INT		AsyncSend();
		void	RingBufPush(INT iRcv);
	};

typedef	std::vector<LnNetIocpHost* >	lsIocpH;
typedef	lsIocpH::iterator				itIocpH;

protected:
	lsIocpH			m_vIoH;														// ���� Ŭ���̾�Ʈ
	LnNetIocpHost	m_pIoH;														// Send/Receive�� Io
	
	HANDLE			m_hIocp;													// IOCP Handle
	HANDLE*			m_hThWrk;													// Work Thread Handle
	DWORD*			m_dThWrk;													// Work Thread Value

	TqueCrc<Tmsg>*	m_pNwMsg;													// �޽��� ť


public:
	CLnNetIocp();
	virtual ~CLnNetIocp();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Close();
	virtual INT		Listen();
	virtual INT		Connect(char* sIp=NULL, char* sPort=NULL);

	virtual INT		Send(char* sSrc, INT* iSnd, SOCKET* scH=NULL);
	virtual INT		Recv(char* sDst, INT* iRcv, SOCKET* scH=NULL);

	virtual DWORD	ProcRecv(void* pParam);
	virtual DWORD	ProcAccp(void* pParam);

protected:
	INT		SendAllData();								// Send Data

	void	MessagePush(SOCKET scH);
	INT		MessagePop(SOCKET* scH);

public:
	HANDLE	GetIocp()	{	return m_hIocp;	}
};

#endif
