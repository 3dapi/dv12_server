// Interface for the CLnNetSlct class.
// Network I/O Select
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetSlct_H_
#define _LnNetSlct_H_


class CLnNetSlct : public CLnNetBase
{
public:
	struct LnNetSlctHost
	{
		TRingBuf	rbSnd;														// ���� Ŭ���̾�Ʈ Send�� ������
		TRingBuf	rbRcv;														// ���� Ŭ���̾�Ʈ Receive�� ������
	};

protected:
	TRingBuf		m_rbSnd;													// Send�� ������
	TRingBuf		m_rbRcv;													// Receive�� ������

	FD_SET			m_rmF;														// ���� FD_SET	rmE: Remote Host FD
	LnNetSlctHost	m_rmH[FD_SETSIZE];

public:
	CLnNetSlct();
	virtual ~CLnNetSlct();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Close();
	virtual INT		Listen();
	virtual INT		Connect(char* sIp=NULL, char* sPort=NULL);

	virtual INT		Send(char* sSrc, INT* iSnd, SOCKET* scH=NULL);
	virtual INT		Recv(char* sDst, INT* iRcv, SOCKET* scH=NULL);

protected:
	INT		FrameMoveSvr();			// For Server
	INT		FrameMoveCln();			// For Client

	INT		SendAllData();			// Send Data

	void	Fd_Set(SOCKET fd, FD_SET* fds);
	void	Fd_Clr(SOCKET fd, FD_SET* fds);
	void	Fd_Zero(FD_SET* fds);
};

#endif