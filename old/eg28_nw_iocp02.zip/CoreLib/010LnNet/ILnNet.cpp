// Implementation of the ILnNet class.
//
////////////////////////////////////////////////////////////////////////////////


#include <WINSOCK2.H>
#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"

#include "LnNetUtil.h"
#include "LnNetBase.h"

#include "LnNetBlc.h"
#include "LnNetBlcN.h"
#include "LnNetSlct.h"
#include "LnNetSlctA.h"
#include "LnNetSlctE.h"
#include "LnNetOvrl.h"
#include "LnNetIocp.h"


INT LnNet_Create(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 , void* p3			// TCP: "TCP" , UDP: "UDP"
				 , void* p4			// Server: "Server", Client: "Client"
				 , void* v1 = NULL	// Ex Value1
				 , void* v2 = NULL	// Ex Value2
				 );




INT LnNet_CreateTcpServer(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 )
{
	return LnNet_Create(sCmd, pData, p1, p2, "TCP", "Server");
}

INT LnNet_CreateTcpClient(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 )
{
	return LnNet_Create(sCmd, pData, p1, p2, "TCP", "Client");
}



INT LnNet_CreateTcpServerEx(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 , void* v1			// Ex Value1
				 , void* v2			// Ex Value2
				 )
{
	return LnNet_Create(sCmd, pData, p1, p2, "TCP", "Server", v1, v2);
}

INT LnNet_CreateTcpClientEx(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 , void* v1			// Ex Value1
				 , void* v2			// Ex Value2
				 )
{
	return LnNet_Create(sCmd, pData, p1, p2, "TCP", "Client", v1, v2);
}





INT LnNet_Create(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 , void* p3			// TCP: "TCP" , UDP: "UDP"
				 , void* p4			// Server: "Server", Client: "Client"
				 , void* v1			// Ex Value1
				 , void* v2			// Ex Value2
				 )
{
	(*pData) = NULL;

	if(0==_stricmp("Blocking", sCmd))
	{
		CLnNetBlc* pObj = NULL;

		pObj = new CLnNetBlc;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;		
		return 0;
	}

	else if(0==_stricmp("Non Blocking", sCmd))
	{
		CLnNetBlcN* pObj = NULL;
		pObj = new CLnNetBlcN;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Select", sCmd))
	{
		CLnNetSlct* pObj = NULL;
		pObj = new CLnNetSlct;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Async Select", sCmd))
	{
		CLnNetSlctA* pObj = NULL;
		pObj = new CLnNetSlctA;

		pObj->Query("Set Window Handle", v1);
		pObj->Query("Set Message Value", v2);

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Event Select", sCmd))
	{
		CLnNetSlctE* pObj = NULL;
		pObj = new CLnNetSlctE;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("Overlapped IO", sCmd))
	{
		CLnNetOvrl* pObj = NULL;
		pObj = new CLnNetOvrl;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	else if(0==_stricmp("IOCP", sCmd))
	{
		CLnNetIocp* pObj = NULL;
		pObj = new CLnNetIocp;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	return -1;
}


