// Implementation of the LnNetUtil functions.
//
////////////////////////////////////////////////////////////////////////////////

#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LnNetUtil.h"



void LnNet_FormatMessage(DWORD hr)
{
	LPVOID	pBuf;

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		hr,
		0,
		(LPTSTR) &pBuf,
		0,
		NULL 
	);

	printf("Error Line:%3d ", __LINE__);
	printf("%s	", __DATE__);
	printf("%s	", __TIME__);
	printf("%s	", __FILE__);

	printf("%s\n", (char*)pBuf);

	LocalFree( pBuf );
}


void LnNet_FormatMessage(char* sMsg)
{
	LPVOID	pBuf;
	DWORD	hr= GetLastError();

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		hr,
		0,
		(LPTSTR) &pBuf,
		0,
		NULL 
	);

	sprintf(sMsg, "%s", (char*)pBuf);
	LocalFree( pBuf );
}



void LnNet_GetNetworkError(DWORD hr)
{
	char	sMsg[512];

	LnNet_FormatMessage(sMsg);

	printf("Error Line:%3d ", __LINE__);
	printf("%s	", __DATE__);
	printf("%s	", __TIME__);
	printf("%s	", __FILE__);

	printf("%s\n", sMsg);

	LocalFree( sMsg );
}



INT LnNet_WSAGetError()
{
	INT		hr = 0;
	char	sMsg[512];

	hr = WSAGetLastError();

	//������ �ƴ� ����.
	if(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr)
		return 0;

	LnNet_FormatMessage(sMsg);

	printf("Line:%d	", __LINE__);
	printf("%s	", __DATE__);
	printf("%s	", __TIME__);
	printf("%s	", __FILE__);

	printf("%s\n", sMsg);

	return -1;
}



INT LnNet_WSAStartup()
{
	INT		hr;
	WORD	wVersion;
	WSADATA wsaData;

	DWORD	iBuf =0;
	INT		nTCP[2] = {IPPROTO_TCP, IPPROTO_UDP};
 
	wVersion = MAKEWORD( 2, 2 );
 
	if ( 0 != WSAStartup( wVersion, &wsaData ))
		return -1;
 
	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 2 )
	{
		WSACleanup();
		return -1; 
	}

	// ������ ũ�⸸ ��ȯ�ϰ� ������ �߻��ؾ� �ȴ�.
	hr = WSAEnumProtocols(0, 0, &iBuf);

	if( (SOCKET_ERROR != hr) && (WSAENOBUFS != WSAGetLastError()) )
	{
		WSACleanup();
		return -1;
	}

	LPWSAPROTOCOL_INFO	pProtoInfo = (LPWSAPROTOCOL_INFO)malloc(iBuf);

	hr = WSAEnumProtocols(nTCP, pProtoInfo, &iBuf);
	free(pProtoInfo);

	if(SOCKET_ERROR ==hr)
	{
		WSACleanup();
		return -1; 
	}

	return 1;
}


void LnNet_WSACleanup()
{
	WSACleanup();
}



INT LnNet_SocketErrorCheck(INT hr)
{
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			LnNet_FormatMessage(hr);
			return -1;
		}
	}

	return 0;
}




void LnNet_SocketAddr(SOCKADDR_IN* pOut, char* sIp, char* sPort)
{
	memset(pOut, 0, sizeof(SOCKADDR_IN));
	pOut->sin_family=AF_INET;

	pOut->sin_addr.s_addr = (sIp) ? inet_addr(sIp): htonl(INADDR_ANY);
	pOut->sin_port=htons(atoi(sPort));
}



void LnNet_SocketClose(SOCKET* scH)
{
	if(*scH<1)
		return;

	::shutdown(*scH, SD_BOTH);
	closesocket(*scH);
	*scH = 0;
}



INT LnNet_SocketTcpCreate(SOCKET* pScH, BOOL bOverLapped)
{
	if(bOverLapped)
		*pScH = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	else
		*pScH = socket(AF_INET, SOCK_STREAM, 0);

	
	if(INVALID_SOCKET == *pScH)
		return -1;

	return 1;
}



INT LnNet_SocketUdpCreate(SOCKET* pScH, BOOL bOverLapped)
{
	return -1;
}





INT LnNet_SocketConnect(SOCKET scH, SOCKADDR_IN* psdH)
{
	INT	hr=-1;

	hr = connect(scH, (SOCKADDR*)psdH, sizeof(SOCKADDR_IN));
	
	// ������ �񵿱��� ��� �̰��� �ݵ�� Ȯ��
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}
	}

	return 1;
}






INT LnNet_SocketBind(SOCKET scH, SOCKADDR_IN* pSdH)
{
	INT hr=-1;

	hr = bind(scH, (SOCKADDR*)pSdH, sizeof(SOCKADDR_IN));

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
		{
			return -1;
		}
	}

	return 1;
}


INT LnNet_SocketListen(SOCKET scH)
{
	INT hr=-1;

	hr = listen(scH, SOMAXCONN);

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
		{
			return -1;
		}
	}

	return 1;
}



INT LnNet_SocketAccept(SOCKET* pscOut, SOCKADDR_IN* psdOut, SOCKET scListen)
{
	INT		hr=-1;
	SOCKET	scCln;
	INT		iSizeAdd = sizeof(SOCKADDR_IN);

	scCln = accept(scListen, (SOCKADDR*)psdOut, &iSizeAdd);
//	scCln = WSAAccept(scH, (SOCKADDR*)&sdCln, &iSizeAdd, NULL, NULL);
	
	// ���������� �񵿱� �ϰ�� �̰��� �ݵ�� Ȯ��
	if(SOCKET_ERROR == scCln || INVALID_SOCKET ==scCln)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}

		// �񵿱���� ��� ���� �ִ�.
		*pscOut =0;
		return 0;
	}

	*pscOut = scCln;

	// ������ ����
	return 1;
}



INT LnNet_SocketSelect(FD_SET* pFdRead, FD_SET* pFdWrite, TIMEVAL* timeout, FD_SET* pFdExcept)
{
	INT hr=-1;

	hr = select(0, pFdRead, pFdWrite, pFdExcept, timeout);

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}
	}

	return hr;
}



INT LnNet_SocketNonBlocking(SOCKET scH, BOOL bOn)
{
	u_long on =bOn? 1: 0;
	return ioctlsocket(scH, FIONBIO, &on);
}

INT LnNet_SocketNaggleOff(SOCKET scH, BOOL bOff)
{
	BOOL bNagle = bOff? 1: 0; // Nagle �˰����� �۵� ����
	return setsockopt(scH, IPPROTO_TCP, TCP_NODELAY, (char*)&bNagle, sizeof bNagle);
}







HANDLE LnNet_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,PVOID pParam, ULONG dFlag, DWORD* dId)
{
	return (HANDLE)_beginthreadex(NULL, 0, (LPBEGIN_THREAD_EX)pFunc, pParam, dFlag, (unsigned*)dId);
}


void LnNet_ThreadClose(HANDLE* hThread)
{
	DWORD	dExit= 0;
	INT		hr	 = 0;
	
	if(0==hThread || 0 == *hThread)
		return;

	GetExitCodeThread(*hThread, &dExit);
	
	if(dExit)
	{
		SuspendThread(*hThread);

		if(0==TerminateThread(*hThread, dExit))
		{
			char	sMsg[512];
			LnNet_FormatMessage(sMsg);
			printf("%s\n", sMsg);
		}
	}

	//	WaitForSingleObject(m_hTh, INFINITE);
	CloseHandle(*hThread);
	*hThread = NULL;
}


DWORD LnNet_ThreadResume(HANDLE* hThread)
{
	if(0==hThread || 0 == *hThread)
		return 0;

	return ::ResumeThread(*hThread);
}



DWORD LnNet_ThreadSuspend(HANDLE* hThread)
{
	if(0==hThread || 0 == *hThread)
		return 0;

	return ::SuspendThread(*hThread);
}





HANDLE LnNet_EventCreate(BOOL bManualReset, BOOL bIntitialState)
{
	return CreateEvent(NULL, bManualReset, bIntitialState, NULL);
}


void LnNet_EventResume(HANDLE hEvent)
{
	SetEvent(hEvent);
}


void LnNet_EventSuspend(HANDLE hEvent)
{
	ResetEvent(hEvent);
}

INT LnNet_EventWait(HANDLE hEvent, DWORD dWaitMillisecond)
{
	DWORD hr=0;
	
	hr = WaitForSingleObject(hEvent, dWaitMillisecond);

	if(WAIT_FAILED == hr)
		return -1;

	else if(WAIT_ABANDONED == hr ||WAIT_OBJECT_0 == hr || WAIT_TIMEOUT == hr)
	{
	}


	return 0;
}


void LnNet_EventClose(HANDLE* hEvent)
{
	if(hEvent && *hEvent)
	{
		CloseHandle(*hEvent);
		*hEvent=NULL;
	}
}


HANDLE	LnNet_WSAEventCreate()
{
	return WSACreateEvent();
}


void LnNet_WSAEventClose(HANDLE* pEvent)
{
	if(pEvent && *pEvent)
	{
		WSACloseEvent( *pEvent );
		*pEvent = 0;
	}
}

INT LnNet_WSAEventSelect(SOCKET scH, HANDLE evEvt, long lEvents)
{
	INT hr= WSAEventSelect(scH, evEvt, lEvents);

	if(SOCKET_ERROR == hr)
		return -1;

	return 0;
}


INT LnNet_WSAEventWaits(INT* pArr/*In,Out*/, INT nSrc/*In*/, HANDLE* pSrc/*In*/)
{
	INT iN=0;
	INT nIdx=-1;

	nIdx = WSAWaitForMultipleEvents(nSrc, pSrc, FALSE, WSA_INFINITE, FALSE);
	nIdx -= WSA_WAIT_EVENT_0;

	if(nIdx<0 || nIdx>=WSA_MAXIMUM_WAIT_EVENTS)
		return -1;		// ������.

	if(1== nSrc)	//�Ѱ��� ������ �ִٸ� �ٷ� �������ش�.
		return 1;		// ������ 1��
		
	for(INT i=nIdx; i<nSrc; ++i)
	{
		nIdx=WSAWaitForMultipleEvents(1, &pSrc[i], TRUE, 0, FALSE);
		
		if((nIdx==WSA_WAIT_FAILED || nIdx==WSA_WAIT_TIMEOUT))
			continue;

		nIdx=i;
		pArr[iN] = i;
		++iN;
	}

	if(iN<0)
		return -1;	// �ƿ� ���� ���� �ش�.

	return iN;		// ������ �����ش�.
}



INT LnNet_WSAEventEnum(SOCKET s, HANDLE e)
{
	WSANETWORKEVENTS	pE;
	
	if(SOCKET_ERROR == WSAEnumNetworkEvents(s, e, &pE))
	{
		printf("Enum Events Error\n");
		return -1;
	}

	if( FD_ACCEPT & pE.lNetworkEvents)				// case Accept
	{
		if( pE.iErrorCode[FD_ACCEPT_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				printf("Accept Error\n");
				return -1;
			}
		}
		
		return FD_ACCEPT;
	}
	
	else if( FD_CONNECT & pE.lNetworkEvents)		// case Connect
	{
		if( pE.iErrorCode[FD_CONNECT_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				printf("Connect Error\n");
				return -1;
			}
		}
		
		return FD_CONNECT;
	}
	
	else if( FD_CLOSE & pE.lNetworkEvents)			// case Close
	{
		if( pE.iErrorCode[FD_CLOSE_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
//				printf("Close Event Error\n");
//				return -1;
			}
		}
		
		return FD_CLOSE;
	}
	
	else if( FD_READ & pE.lNetworkEvents)			// case Read
	{
		if( pE.iErrorCode[FD_READ_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				printf("Read Error\n");
				return -1;
			}
		}
		
		return FD_READ;
	}

	else if( FD_WRITE & pE.lNetworkEvents)			// case Write
	{
		if( pE.iErrorCode[FD_WRITE_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				printf("Write Error\n");
				return -1;
			}
		}
		
		return FD_WRITE;
	}
	
	// �ٸ� �޽��� �̸�
//	printf("Other Message.%d\n", pE.lNetworkEvents);
	
	return 0;
}




INT	LnNet_GetSystemProcessNumber()
{
	SYSTEM_INFO SystemInfo;

	GetSystemInfo(&SystemInfo);
	
	return INT(SystemInfo.dwNumberOfProcessors);
}


HANDLE LnNet_IocpPortCreate(SOCKET scH, HANDLE hIocp, void* pAddress)
{
	return CreateIoCompletionPort((HANDLE)(scH), hIocp, (DWORD)pAddress, 0);
}








// Implementation of the TRingBuf class.
//
////////////////////////////////////////////////////////////////////////////////	

TRingBuf::TRingBuf(): F(0), L(0), W(0), S(0)
{
#if	PCK_USE_BUF_POINTER
	B	= NULL;
	W	= 0;
#else
	W	= PCK_BUF_MAX_QUEUE;
	memset(B, 0, W);
#endif
}


TRingBuf::TRingBuf(INT iSize): F(0), L(0), W(iSize), S(0)
{
#if	PCK_USE_BUF_POINTER
	B	= new BYTE[W];
#endif
	memset(B, 0, W);
}


TRingBuf::~TRingBuf()
{
	W	= 0;
	F	= 0;
	L	= 0;

#if	PCK_USE_BUF_POINTER
	if(B)
	{
		delete [] B;
		B= NULL;
	}
#endif
}

void TRingBuf::SetSize(INT iSize)
{
	F	= 0;
	L	= 0;

#if	PCK_USE_BUF_POINTER
	W	= iSize;
	
	if(B)
	{
		delete [] B;
		B= NULL;
	}
	
	B	= new BYTE[W];
#else
	W	= PCK_BUF_MAX_QUEUE;
#endif
	
	memset(B, 0, W);
}



INT TRingBuf::End()		{	return L;	}
INT TRingBuf::Front()		{	return F;	}
INT TRingBuf::GetStore()	{	return S;	}

void TRingBuf::Clear()
{
	F	= 0;
	L	= 0;
	S	= 0;	
	memset(B, 0, W);
}

INT TRingBuf::PushBack(BYTE* /*In*/pSrc, INT iSize/*Length*/)
{
	// �� ������ ����...
	if( W<(iSize+S))
		return -1;

	INT	iLen = iSize;

	while(iLen--)
	{
		*(B+L) = *(pSrc++);
		++L;
		L %= W;
	}

	S +=iSize;

	return 1;
}


INT TRingBuf::PopFront(BYTE* /*Out*/pDst, WORD* iSize/*Length*/)
{
	BYTE	sSize[PCK_BUF_HEAD];
	INT		T= F;
	WORD	iLen=0;

	// ����Ʈ�� 2����Ʈ �̵����� ����.
	*(sSize+0) = *(B+T);
	++T;
	T%=W;

	*(sSize+1) = *(B+T);
	++T;
	T%=W;


	*iSize = 0;

	// �̵��ߴµ� L���� ũ�ų� ������ ���� �ϼ��� ��Ŷ�� ���ٴ� ��.
	if(T>=L)
		return -1;

	// ����Ǿ� �ִ� ��Ŷ�� ��
	iLen = *((WORD*)sSize);

	// ����� ����Ǿ� �ִ� �ͺ��� ũ�� ���� �ϼ��� ��Ŷ�� ����.
	if(iLen>S)
		return -1;

	//���� ���ۿ� ��Ŷ�� �����Ѵ�.
	WORD	iL= iLen;
	
	while (iLen--)
	{
		*(pDst++) = *(B + F);
		*(B + F) =0;

		++F;
		F %=W;
	}

	// ��ü �׿� �ִ� ��Ŷ�� ���� �����Ѵ�.
	S -= iL;
	*iSize = iL;

	return 1;
}