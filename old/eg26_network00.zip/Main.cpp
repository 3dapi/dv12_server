// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "include/LnLib/LnType.h"
#include "include/LnLib/ILnNet.h"

#include "Main.h"


CMain*			g_pAppMain;
extern ILnNet*	g_pNet;



CMain::CMain()
{
	g_pAppMain = this;

	

}


CMain::~CMain()
{
}


INT CMain::Init()
{
	INT hr=-1;

	return 0;
}

void CMain::Destroy()
{
	printf("Call CMain::Destroy()\n");
}


INT CMain::Restore()
{
	printf("Call CMain::Restore()\n");

	return 0;
}


void  CMain::Invalidate()
{
	printf("Call CMain::Invalidate()\n");
}


INT  CMain::FrameMove()
{
	static int c=0;

	if(++c>100)
	{
//		return -1;
	}

	printf("Call CMain::FrameMove(%d)\n", c);
	
	return 0;
}


void  CMain::Render()
{
}