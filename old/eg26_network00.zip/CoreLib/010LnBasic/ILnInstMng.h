// Interface for the ILnInstMng class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnInstMng_H_
#define _ILnInstMng_H_

#ifndef interface
#define interface struct
#endif



interface ILnInstMng
{
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual INT		Find(char* sCmd, void* pData)=0;

	virtual INT		Query(char* sCmd, void* pData)=0;
};


INT LnInst_CreateMng(char* sCmd, ILnInstMng** pData);


#endif

