// Implementation of the CLnNetBlc class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"
#include "LnNetBlc.h"



CLnNetBlc::CLnNetBlc()
{
}


CLnNetBlc::~CLnNetBlc()
{
}

INT CLnNetBlc::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetBlc Create\n");

	return 0;
}

void CLnNetBlc::Destroy()
{
	printf("CLnNetBlc Destroy\n");
}


INT	CLnNetBlc::FrameMove()
{
	printf("CLnNetBlc FrameMove\n");

	return 0;
}


INT CLnNetBlc::Query(char* sCmd, void* pData)
{
	printf("CLnNetBlc Query:%s\n", sCmd);

	if(0==_stricmp("SetScnStyle", sCmd))
	{
		DWORD	dVal = *((DWORD*)pData);
	}

	return 0;
}

