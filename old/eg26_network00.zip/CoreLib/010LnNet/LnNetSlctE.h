// Interface for the CLnNetSlctE class.
// Network I/O Event Select
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetSlctE_H_
#define _LnNetSlctE_H_


class CLnNetSlctE : public CLnNetBase
{
protected:


public:
	CLnNetSlctE();
	virtual ~CLnNetSlctE();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

protected:

};

#endif
