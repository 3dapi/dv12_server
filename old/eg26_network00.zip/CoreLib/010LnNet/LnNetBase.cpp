// Implementation of the CLnNetBase class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnNet.h"
#include "LnNetBase.h"


CLnNetBase::CLnNetBase()
{
	
}

CLnNetBase::~CLnNetBase()
{
	Destroy();
}


INT CLnNetBase::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnNetBase Create\n");
	return 0;
}


void CLnNetBase::Destroy()
{
	printf("CLnNetBase Destroy\n");
}


INT	CLnNetBase::FrameMove()
{
	printf("CLnNetBase FrameMove\n");
	return 0;
}


INT CLnNetBase::Query(char* sCmd, void* pData)
{
	printf("CLnNetBase Query:%s\n", sCmd);
	return 0;
}

