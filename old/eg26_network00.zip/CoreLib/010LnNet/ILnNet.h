// Interface for the ILnNet class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnNet_H_
#define _ILnNet_H_

#ifndef interface
#define interface struct
#endif


struct LnNet
{
	INT			PosX;		// Position X
	INT			PosY;		// Position Y
	INT			ScnX;		// Client Rect Width
	INT			ScnY;		// Client Rect Height

	LnNet();
};



interface ILnNet
{
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;
	virtual INT		FrameMove()=0;
	virtual INT		Query(char* sCmd, void* pData)=0;
};


INT LnNet_Create(char* sCmd
				 , ILnNet** pData
				 , void* p1			// IP
				 , void* p2			// Port
				 , void* p3=NULL	// Etc. Not Use...
				 , void* p4=NULL	// Etc. Not Use...
				 );


#ifdef _DEBUG
	#pragma comment(lib, "LnNet_.lib")
#else
	#pragma comment(lib, "LnNet.lib")
#endif


#endif

