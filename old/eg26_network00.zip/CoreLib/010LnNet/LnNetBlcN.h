// Interface for the CLnNetBlcN class.
// Network I/O Non Blocking
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetBlcN_H_
#define _LnNetBlcN_H_


class CLnNetBlcN : public CLnNetBase
{
protected:


public:
	CLnNetBlcN();
	virtual ~CLnNetBlcN();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

protected:

};

#endif
