// Interface for the CLnNetBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnNetBase_H_
#define _LnNetBase_H_


class CLnNetBase : public ILnNet
{
protected:
	INT		nId;

public:
	CLnNetBase();
	virtual ~CLnNetBase();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Query(char* sCmd, void* pData);

public:

};

#endif
