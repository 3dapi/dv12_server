// Interface for the CCMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _Main_H_
#define _Main_H_


class CMain
{
protected:


public:
	CMain();
	virtual ~CMain();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual void	Render();
};

#endif
