

#include <windows.h>
#include <stdio.h>


#include "include/LnLib/LnType.h"
#include "include/LnLib/ILnNet.h"

#include "Main.h"


// �ν��Ͻ�
CMain*		g_pApp=NULL;
ILnNet*		g_pNet=NULL;


void main()
{
	CMain	mainApp;
	g_pApp	= &mainApp;

	LnNet	Nets;

	printf("\n��Ʈ��ũ �غ�--------------------\n");
	LnNet_Create("Blocking", &g_pNet, "127.0.0.1", "20000", &Nets);


	printf("\n\n��Ʈ��ũ ����--------------------\n");
	g_pNet->FrameMove();
	delete g_pNet;

	LnNet_Create("Non Blocking", &g_pNet, "127.0.0.1", "20000", &Nets);
	g_pNet->FrameMove();
	delete g_pNet;

	LnNet_Create("Select", &g_pNet, "127.0.0.1", "20000", &Nets);
	g_pNet->FrameMove();
	delete g_pNet;

	LnNet_Create("Event Select", &g_pNet, "127.0.0.1", "20000", &Nets);
	g_pNet->FrameMove();
	delete g_pNet;

	LnNet_Create("Async Select", &g_pNet, "127.0.0.1", "20000", &Nets);
	g_pNet->FrameMove();
	delete g_pNet;

	LnNet_Create("Overlapped IO", &g_pNet, "127.0.0.1", "20000", &Nets);
	g_pNet->FrameMove();
	delete g_pNet;

	LnNet_Create("IOCP", &g_pNet, "127.0.0.1", "20000", &Nets);
	g_pNet->FrameMove();
	delete g_pNet;

	printf("\n��Ʈ��ũ ����--------------------\n\n");

	return;
}

