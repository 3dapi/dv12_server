// Server Application
//
////////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "Winmm.lib")

#include <windows.h>
#include <Mmsystem.h>
#include <stdio.h>


#include "../include/LnLib/ILnNet.h"


ILnNet*		g_pNet=NULL;				// Network Instance


void main()
{
	printf("\n��Ʈ��ũ �غ�--------------------\n");

	// ������ �ʱ�ȭ
	if(FAILED(LnNet_WinSockCreate()))
		return;


	if(FAILED(LnNet_CreateTcpServer("Event Select", &g_pNet, NULL, "20000")))
		return;

	printf("\n\n��Ʈ��ũ ����--------------------\n");


	char	sBufSnd[1024]={0};
	char	sBufRcv[1024]={0};
	int		iLenSnd=0;
	int		iLenRcv=0;

	while(1)
	{
		Sleep(10);

		INT nCnt =0;

		if(SUCCEEDED(g_pNet->Query("Get Client Number", &nCnt)))
		{
			for(int i=0; i<nCnt; ++i)
			{
				SOCKET scH = i;
				
				memset(sBufRcv, 0, sizeof sBufRcv);
				g_pNet->Recv(sBufRcv, &iLenRcv, &scH);

				if(iLenRcv>0)
				{
					printf("Recv:%s\n", sBufRcv);
					sprintf(sBufSnd, "Echo:%s", sBufRcv);
					iLenSnd=strlen(sBufSnd);

					g_pNet->Send(sBufSnd, &iLenSnd, &scH);
				}
			}
		}

		if(FAILED(g_pNet->FrameMove()))
			break;
	}

	printf("\n��Ʈ��ũ ����--------------------\n\n");
	delete g_pNet;

	// ��������
	LnNet_WinsockDestroy();
}



